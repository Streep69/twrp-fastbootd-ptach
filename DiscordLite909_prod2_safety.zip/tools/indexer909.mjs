#!/usr/bin/env node
/**
 * indexer909.mjs (999)
 * Deterministic repository index + lightweight 256-bit token-simhash vector.
 *
 * Outputs:
 *  - index/manifest.json
 *  - index/chunks.jsonl   (one JSON per chunk)
 */
import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const ROOT = process.argv[2] ? path.resolve(process.argv[2]) : process.cwd();
const OUT_DIR = path.join(ROOT, 'index');
const CHUNKS_PATH = path.join(OUT_DIR, 'chunks.jsonl');
const MANIFEST_PATH = path.join(OUT_DIR, 'manifest.json');

const SKIP_DIR = new Set(['node_modules', '.git', '.next', 'pg_data', 'index', 'security/logs', 'dist', 'build', '.turbo']);
const INCLUDE_EXT = new Set(['.js','.mjs','.cjs','.ts','.tsx','.jsx','.json','.yml','.yaml','.sql','.ps1','.sh','.md','.txt']);

function walk(dir, out=[]) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) {
      if (SKIP_DIR.has(e.name)) continue;
      walk(p, out);
    } else if (e.isFile()) {
      const ext = path.extname(p).toLowerCase();
      if (INCLUDE_EXT.has(ext)) out.push(p);
    }
  }
  return out;
}

function sha256(buf) {
  return crypto.createHash('sha256').update(buf).digest('hex');
}

function tokenize(text) {
  return text
    .toLowerCase()
    .replace(/[^a-z0-9_\-\s]+/g, ' ')
    .split(/\s+/)
    .filter(t => t.length >= 2 && t.length <= 64);
}

// 256-bit simhash over tokens
function simhash256(tokens) {
  const bits = new Array(256).fill(0);
  for (const t of tokens) {
    const h = crypto.createHash('sha256').update(t).digest(); // 32 bytes = 256 bits
    for (let i=0;i<256;i++) {
      const byte = h[Math.floor(i/8)];
      const bit = (byte >> (7-(i%8))) & 1;
      bits[i] += bit ? 1 : -1;
    }
  }
  // build hex
  const out = Buffer.alloc(32, 0);
  for (let i=0;i<256;i++) {
    if (bits[i] > 0) {
      out[Math.floor(i/8)] |= (1 << (7-(i%8)));
    }
  }
  return out.toString('hex');
}

function chunkText(text, maxChars=1800) {
  const lines = text.split(/\r?\n/);
  const chunks = [];
  let cur = [];
  let curLen = 0;
  for (const ln of lines) {
    if (curLen + ln.length + 1 > maxChars && cur.length) {
      chunks.push(cur.join('\n'));
      cur = [];
      curLen = 0;
    }
    cur.push(ln);
    curLen += ln.length + 1;
  }
  if (cur.length) chunks.push(cur.join('\n'));
  return chunks;
}

fs.mkdirSync(OUT_DIR, { recursive: true });
if (fs.existsSync(CHUNKS_PATH)) fs.unlinkSync(CHUNKS_PATH);

const files = walk(ROOT).sort();
const manifest = {
  version: '909.999',
  root: ROOT,
  generated_at: new Date().toISOString(),
  file_count: files.length,
  files: []
};

const chunkStream = fs.createWriteStream(CHUNKS_PATH, { flags: 'a' });

for (const abs of files) {
  const rel = path.relative(ROOT, abs).replace(/\\/g, '/');
  const buf = fs.readFileSync(abs);
  const text = buf.toString('utf8');
  const fileHash = sha256(buf);
  const tokens = tokenize(text);
  const vec256 = simhash256(tokens.slice(0, 5000));
  const chunks = chunkText(text);

  manifest.files.push({
    path: rel,
    bytes: buf.length,
    sha256: fileHash,
    vec256,
    chunks: chunks.length
  });

  for (let i=0;i<chunks.length;i++) {
    const c = chunks[i];
    const ctoks = tokenize(c);
    const cvec = simhash256(ctoks);
    const rec = {
      path: rel,
      chunk: i,
      text: c,
      sha256: sha256(Buffer.from(c, 'utf8')),
      vec256: cvec
    };
    chunkStream.write(JSON.stringify(rec) + '\n');
  }
}
chunkStream.end();
fs.writeFileSync(MANIFEST_PATH, JSON.stringify(manifest, null, 2));
console.log('INDEXER909_OK', { files: manifest.file_count, out: 'index/' });
