#!/usr/bin/env bash
set -euo pipefail

echo "[787] DL909 self-test starting…"

cd "$(dirname "$0")/.."

if ! command -v docker >/dev/null 2>&1; then
  echo "[787] ERROR: docker not found"
  exit 1
fi

if ! command -v docker compose >/dev/null 2>&1; then
  echo "[787] ERROR: docker compose not found"
  exit 1
fi

if [ ! -f .env ]; then
  echo "[787] No .env found. Running installer to generate secrets…"
  bash scripts/install.sh
fi

echo "[787] Bringing stack up…"
docker compose up -d --build

echo "[787] Waiting for backend health…"
for i in {1..60}; do
  if curl -fsS http://localhost:8787/health >/dev/null 2>&1; then
    echo "[787] Backend healthy ✅"
    break
  fi
  sleep 1
done

echo "[787] Done. Open UI: http://localhost:3000"
echo "[787] SuperAdmin needs SUPERADMIN_KEY header for admin endpoints."
