#!/usr/bin/env node
/**
 * sandbox787.mjs
 * Local/CI validation for DiscordLite909.
 * Controls:
 *  - SKIP_INDEX_999=1 to skip running indexer909.
 */
import fs from 'node:fs';
import path from 'node:path';
import { spawnSync } from 'node:child_process';

const ROOT = process.cwd();
const mustExist = [
  'docker-compose.yml',
  'livekit.yaml',
  'backend/package.json',
  'backend/src/index.js',
  'backend/src/db/schema.sql',
  'frontend/package.json',
  'frontend/app/page.js',
  'tools/indexer909.mjs',
  'tools/unicode_sanitizer909.mjs'
];

let ok = true;
for (const f of mustExist) {
  if (!fs.existsSync(path.join(ROOT, f))) {
    console.error('MISSING', f);
    ok = false;
  }
}

// refuse obvious placeholders
const SKIP_DIR = new Set(['node_modules','.git','.next','pg_data','index','security/logs','dist','build']);
const INCLUDE_EXT = new Set(['.js','.mjs','.cjs','.ts','.tsx','.jsx','.json','.yml','.yaml','.sql','.ps1','.sh','.md']);
const bad = [/\bTODO\b/i, /\bFIXME\b/i, /pseudocode/i];

function walk(dir, out=[]) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) {
      if (SKIP_DIR.has(e.name)) continue;
      walk(p, out);
    } else if (e.isFile()) {
      const ext = path.extname(p).toLowerCase();
      if (INCLUDE_EXT.has(ext)) out.push(p);
    }
  }
  return out;
}

for (const f of walk(ROOT)) {
  const rel = path.relative(ROOT, f).replace(/\\/g, '/');
  if (rel === 'tools/sandbox787.mjs') continue;
  let txt = '';
  try { txt = fs.readFileSync(f, 'utf8'); } catch { continue; }
  for (const r of bad) {
    if (r.test(txt)) {
      console.error('MARKER_FOUND', r.toString(), 'in', rel);
      ok = false;
      break;
    }
  }
  if (!ok) break;
}

if (process.env.SKIP_INDEX_999 === '1') {
  console.log('Skipping 999 index (SKIP_INDEX_999=1)');
} else {
  console.log('Running 999 indexer909…');
  const r = spawnSync('node', ['tools/indexer909.mjs', '.'], { stdio: 'inherit' });
  if (r.status !== 0) ok = false;
  if (!fs.existsSync(path.join(ROOT, 'index/manifest.json'))) {
    console.error('MISSING index/manifest.json');
    ok = false;
  }
}

console.log(ok ? 'SANDBOX787_OK' : 'SANDBOX787_FAIL');
process.exit(ok ? 0 : 1);
