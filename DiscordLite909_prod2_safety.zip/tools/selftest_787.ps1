param()

$ErrorActionPreference = "Stop"
Write-Host "[787] DL909 self-test starting…" -ForegroundColor Cyan

Set-Location (Join-Path $PSScriptRoot "..")

if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
  Write-Host "[787] ERROR: docker not found" -ForegroundColor Red
  exit 1
}

if (-not (Test-Path ".env")) {
  Write-Host "[787] No .env found. Running installer to generate secrets…" -ForegroundColor Yellow
  & powershell -ExecutionPolicy Bypass -File "scripts\\install.ps1"
}

Write-Host "[787] Bringing stack up…" -ForegroundColor Cyan
& docker compose up -d --build | Out-Host

Write-Host "[787] Waiting for backend health…" -ForegroundColor Cyan
for ($i=0; $i -lt 60; $i++) {
  try {
    $r = Invoke-WebRequest -Uri "http://localhost:8787/health" -UseBasicParsing -TimeoutSec 2
    if ($r.StatusCode -eq 200) { Write-Host "[787] Backend healthy ✅" -ForegroundColor Green; break }
  } catch { Start-Sleep -Seconds 1 }
}

Write-Host "[787] Done. Open UI: http://localhost:3000" -ForegroundColor Green
Write-Host "[787] SuperAdmin needs SUPERADMIN_KEY header for admin endpoints." -ForegroundColor Yellow
