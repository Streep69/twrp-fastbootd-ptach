/**
 * 909 DB Exporter -> JSONL + simhash signatures.
 * Exports messages, audit_events, uploads into ./index/runtime_export_*.jsonl
 *
 * Usage:
 *   node tools/db_export909.mjs --out index/runtime_export.jsonl
 *
 * Requires:
 *   DATABASE_URL in environment (same as backend)
 */
import fs from 'node:fs';
import crypto from 'node:crypto';
import pg from 'pg';

function arg(name, def=null) {
  const i = process.argv.indexOf(name);
  if (i === -1) return def;
  return process.argv[i+1] ?? def;
}

function sha256hex(s) {
  const h = crypto.createHash('sha256');
  h.update(String(s));
  return h.digest('hex');
}

async function main() {
  const out = arg('--out', `index/runtime_export_${Date.now()}.jsonl`);
  fs.mkdirSync(out.split('/').slice(0,-1).join('/') || '.', { recursive: true });
  const pool = new pg.Pool({ connectionString: process.env.DATABASE_URL });

  const ws = fs.createWriteStream(out, { encoding:'utf8' });

  async function dump(sql, params, kind) {
    const r = await pool.query(sql, params);
    for (const row of r.rows) {
      const doc = { kind, ts: row.ts || row.created_at || null, id: row.id, data: row };
      doc.sig = sha256hex(JSON.stringify(doc.data)).slice(0, 32);
      ws.write(JSON.stringify(doc) + "\n");
    }
  }

  await dump("SELECT id, created_at, user_id, channel_id, content FROM messages ORDER BY created_at DESC LIMIT 50000", [], "message");
  await dump("SELECT id, ts, actor_user_id, actor_username, kind, route, method, status, meta FROM audit_events ORDER BY ts DESC LIMIT 50000", [], "audit");
  await dump("SELECT id, created_at, user_id, channel_id, filename, sha256, size_bytes, status FROM uploads ORDER BY created_at DESC LIMIT 50000", [], "upload");

  ws.end();
  await pool.end();
  console.log(`[909] wrote ${out}`);
}

main().catch(e => { console.error(e); process.exit(1); });
