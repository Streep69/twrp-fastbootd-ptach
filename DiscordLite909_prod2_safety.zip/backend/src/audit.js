import crypto from 'node:crypto';
import { query } from './db/pool.js';
import { enqueueDiscordLog } from './discordOutbox.js';

function sha256hex(s) {
  const h = crypto.createHash('sha256');
  h.update(String(s));
  return h.digest('hex');
}

export async function auditEvent({
  kind,
  actorUserId=null,
  actorUsername=null,
  ip=null,
  userAgent=null,
  method=null,
  route=null,
  status=null,
  serverId=null,
  channelId=null,
  meta={}
}) {
  try {
    await query(
      `INSERT INTO audit_events
       (kind, actor_user_id, actor_username, ip, user_agent, method, route, status, server_id, channel_id, meta)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11::jsonb)`,
      [
        kind,
        actorUserId,
        actorUsername,
        ip,
        userAgent,
        method,
        route,
        status,
        serverId,
        channelId,
        JSON.stringify(meta || {})
      ]
    );

    // Optional Discord audit mirror (best-effort)
    await enqueueDiscordLog({ level: 'info', payload: { kind, actorUserId, actorUsername, route, method, status, serverId, channelId, meta } });
  } catch (e) {
    // never block app on audit failure
    console.error('auditEvent failed', e?.message || e);
  }
}

export function requestAuditMiddleware() {
  return async (req, res, next) => {
    const start = Date.now();
    const ip = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || '').toString().split(',')[0].trim();
    const ua = (req.headers['user-agent'] || '').toString();
    const method = req.method;
    const route = req.path;

    // capture body safely (hash only)
    let bodyHash = null;
    try {
      if (req.body && Object.keys(req.body).length) bodyHash = sha256hex(JSON.stringify(req.body));
    } catch {}

    res.on('finish', () => {
      const status = res.statusCode;
      const durMs = Date.now() - start;
      const user = req.user || null;

      auditEvent({
        kind: 'http.request',
        actorUserId: user?.id || null,
        actorUsername: user?.username || null,
        ip,
        userAgent: ua,
        method,
        route,
        status,
        meta: { durMs, bodyHash }
      });
    });

    return next();
  };
}

export async function listAudit({ limit=200, cursorTs=null } = {}) {
  const lim = Math.max(1, Math.min(2000, Number(limit) || 200));
  if (cursorTs) {
    const r = await query(
      `SELECT * FROM audit_events WHERE ts < $1 ORDER BY ts DESC LIMIT $2`,
      [cursorTs, lim]
    );
    return r.rows;
  }
  const r = await query(`SELECT * FROM audit_events ORDER BY ts DESC LIMIT $1`, [lim]);
  return r.rows;
}
