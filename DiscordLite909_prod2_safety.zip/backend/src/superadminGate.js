import { authenticator } from 'otplib';

export function requireSuperadminKey(req, res, next) {
  const expected = process.env.SUPERADMIN_KEY || '';
  if (!expected) return next(); // optional: if not set, skip
  const got = (req.headers['x-superadmin-key'] || '').toString();
  if (!got || got !== expected) return res.status(403).json({ error: 'superadmin key required' });

  const totpSecret = process.env.SUPERADMIN_TOTP_SECRET || '';
  if (totpSecret) {
    const code = (req.headers['x-superadmin-totp'] || '').toString().trim();
    if (!code) return res.status(403).json({ error: 'superadmin totp required' });
    try {
      authenticator.options = { window: 1 };
      if (!authenticator.check(code, totpSecret)) return res.status(403).json({ error: 'invalid totp' });
    } catch {
      return res.status(403).json({ error: 'totp check failed' });
    }
  }
  return next();
}
