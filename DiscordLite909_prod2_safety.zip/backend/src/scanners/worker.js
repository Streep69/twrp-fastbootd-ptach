import fs from 'node:fs';
import { query } from '../db/pool.js';
import { getSetting } from '../settings.js';
import { auditEvent } from '../audit.js';
import { vtUploadFile, vtGetAnalysis, classifyVTAnalysis, fileIsOversizeForPublicVT } from './virustotal.js';

function sleep(ms) { return new Promise(r => setTimeout(r, ms)); }

async function pickJob() {
  // pick next queued or rate_limited job ready to retry
  const r = await query(
    `SELECT id, upload_id, scanner, status, tries, next_try_at
     FROM upload_scans
     WHERE (status IN ('queued','rate_limited') AND (next_try_at IS NULL OR next_try_at <= now()))
     ORDER BY created_at ASC
     LIMIT 1`
  );
  return r.rowCount ? r.rows[0] : null;
}

async function getUpload(uploadId) {
  const r = await query(`SELECT * FROM uploads WHERE id=$1`, [uploadId]);
  return r.rowCount ? r.rows[0] : null;
}

async function updateJob(id, fields) {
  const keys = Object.keys(fields);
  const cols = keys.map((k,i)=>`${k}=$${i+2}`);
  const vals = keys.map(k=>fields[k]);
  await query(`UPDATE upload_scans SET ${cols.join(',')}, updated_at=now() WHERE id=$1`, [id, ...vals]);
}

async function setUploadStatus(uploadId, status) {
  await query(`UPDATE uploads SET status=$2 WHERE id=$1`, [uploadId, status]);
}

async function runOnce() {
  const apiKey = await getSetting('virustotal.api_key', process.env.VT_API_KEY || '');
  const vtEnabled = String(await getSetting('virustotal.enabled', process.env.VT_ENABLED || '0')) === '1';
  if (!vtEnabled || !apiKey) return;

  const job = await pickJob();
  if (!job) return;

  const upload = await getUpload(job.upload_id);
  if (!upload) {
    await updateJob(job.id, { status: 'error', last_error: 'upload missing' });
    return;
  }

  // oversize: skip vt upload (public endpoint limit) - mark oversize and require manual
  if (fileIsOversizeForPublicVT(upload.size_bytes)) {
    await updateJob(job.id, { status: 'done', result: JSON.stringify({ oversize: true, note: 'File >32MB. Public VT endpoint requires upload_url or private scanning.' }) });
    await setUploadStatus(upload.id, 'oversize');
    await auditEvent({ kind:'upload.scan.oversize', actorUserId:null, actorUsername:null, meta:{ uploadId: upload.id, size: upload.size_bytes } });
    return;
  }

  try {
    const tries = Number(job.tries || 0) + 1;
    await updateJob(job.id, { status: 'uploading', tries });

    // upload file
    const up = await vtUploadFile({ apiKey, filePath: upload.storage_path });
    if (!up.ok) {
      // quota hit -> 429
      if (up.status === 429) {
        const next = new Date(Date.now() + 60_000).toISOString();
        await updateJob(job.id, { status: 'rate_limited', next_try_at: next, last_error: String(up.error || 'rate limited') });
        return;
      }
      await updateJob(job.id, { status: 'error', last_error: String(up.error || 'upload failed') });
      await setUploadStatus(upload.id, 'failed');
      return;
    }

    await updateJob(job.id, { status: 'polling', vt_analysis_id: up.analysisId });

    // poll analysis
    for (let i=0; i<30; i++) {
      const an = await vtGetAnalysis({ apiKey, analysisId: up.analysisId });
      if (!an.ok) {
        if (an.status === 429) {
          const next = new Date(Date.now() + 60_000).toISOString();
          await updateJob(job.id, { status: 'rate_limited', next_try_at: next, last_error: String(an.error || 'rate limited') });
          return;
        }
        await sleep(2000);
        continue;
      }

      const attrs = an.raw?.data?.attributes || {};
      const st = attrs?.status || '';
      if (st && st !== 'completed') {
        await sleep(1500);
        continue;
      }

      const cls = classifyVTAnalysis(an.raw);
      const result = { verdict: cls.verdict, stats: cls.stats, analysis: an.raw?.data?.id || up.analysisId };
      await updateJob(job.id, { status: 'done', result: JSON.stringify(result) });

      if (cls.verdict === 'malicious') await setUploadStatus(upload.id, 'malicious');
      else if (cls.verdict === 'clean') await setUploadStatus(upload.id, 'clean');
      else await setUploadStatus(upload.id, 'blocked');

      await auditEvent({ kind:'upload.scan.done', actorUserId:null, actorUsername:null, meta:{ uploadId: upload.id, verdict: cls.verdict, stats: cls.stats } });
      return;
    }

    // timeout -> keep pending
    await updateJob(job.id, { status: 'error', last_error: 'analysis timeout' });
  } catch (e) {
    await updateJob(job.id, { status: 'error', last_error: String(e?.message || e) });
    await setUploadStatus(upload.id, 'failed');
  }
}

export function startScanWorker() {
  const enabled = String(process.env.SCAN_WORKER_ENABLED || '1') === '1';
  if (!enabled) return;

  const intervalMs = Number(process.env.SCAN_WORKER_INTERVAL_MS || 2000);
  setInterval(() => runOnce().catch(e => console.error('scan worker error', e)), intervalMs);
}
