import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';

const VT_BASE = 'https://www.virustotal.com/api/v3';

export function fileIsOversizeForPublicVT(sizeBytes) {
  // Docs say >32MB needs upload_url endpoint
  return Number(sizeBytes) > (32 * 1024 * 1024);
}

function authHeaders(apiKey) {
  return { 'x-apikey': apiKey };
}

export async function vtUploadFile({ apiKey, filePath }) {
  const stat = fs.statSync(filePath);
  const filename = path.basename(filePath);

  const form = new FormData();
  form.append('file', new Blob([fs.readFileSync(filePath)]), filename);

  const res = await fetch(`${VT_BASE}/files`, {
    method: 'POST',
    headers: { ...authHeaders(apiKey) },
    body: form
  });

  const text = await res.text();
  let data = null;
  try { data = JSON.parse(text); } catch {}

  if (!res.ok) {
    const err = data?.error?.message || data?.error || text || `HTTP ${res.status}`;
    return { ok: false, status: res.status, error: err, raw: data || text };
  }

  // typical: { data: { id: 'analysis-id', type: 'analysis' } }
  const analysisId = data?.data?.id || null;
  return { ok: true, analysisId, raw: data };
}

export async function vtGetAnalysis({ apiKey, analysisId }) {
  const res = await fetch(`${VT_BASE}/analyses/${encodeURIComponent(analysisId)}`, {
    headers: authHeaders(apiKey)
  });
  const text = await res.text();
  let data = null;
  try { data = JSON.parse(text); } catch {}
  if (!res.ok) {
    const err = data?.error?.message || data?.error || text || `HTTP ${res.status}`;
    return { ok: false, status: res.status, error: err, raw: data || text };
  }
  return { ok: true, raw: data };
}

export function classifyVTAnalysis(analysisObj) {
  // analysisObj: vt analysis JSON. We use stats if present.
  const attrs = analysisObj?.data?.attributes || {};
  const stats = attrs?.stats || {};
  const malicious = Number(stats?.malicious || 0);
  const suspicious = Number(stats?.suspicious || 0);
  const harmless = Number(stats?.harmless || 0);
  const undetected = Number(stats?.undetected || 0);

  // simple policy: any malicious -> malicious; else suspicious -> suspicious; else clean
  if (malicious > 0) return { verdict: 'malicious', stats };
  if (suspicious > 0) return { verdict: 'suspicious', stats };
  return { verdict: 'clean', stats };
}
