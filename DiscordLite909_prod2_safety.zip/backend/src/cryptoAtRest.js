import crypto from 'node:crypto';

function getKey() {
  const k = process.env.MESSAGE_AT_REST_KEY || '';
  if (!k) return null;

  // allow base64 or hex
  let raw;
  try {
    if (/^[0-9a-fA-F]{64}$/.test(k)) raw = Buffer.from(k, 'hex');
    else raw = Buffer.from(k, 'base64');
  } catch {
    throw new Error('MESSAGE_AT_REST_KEY must be 32-byte base64 or 64-hex');
  }
  if (raw.length !== 32) throw new Error('MESSAGE_AT_REST_KEY must be 32 bytes');
  return raw;
}

export function encryptAtRest(plaintext) {
  const key = getKey();
  if (!key) return plaintext; // disabled
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const ct = Buffer.concat([cipher.update(String(plaintext), 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `enc:v1:${iv.toString('base64')}:${tag.toString('base64')}:${ct.toString('base64')}`;
}

export function decryptAtRest(value) {
  const key = getKey();
  if (!key) return value;
  if (!String(value).startsWith('enc:v1:')) return value;

  const parts = String(value).split(':');
  if (parts.length !== 5) return value;
  const iv = Buffer.from(parts[2], 'base64');
  const tag = Buffer.from(parts[3], 'base64');
  const ct = Buffer.from(parts[4], 'base64');

  const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
  decipher.setAuthTag(tag);
  const pt = Buffer.concat([decipher.update(ct), decipher.final()]);
  return pt.toString('utf8');
}
