import { query } from './db/pool.js';
import { getSetting } from './settings.js';

function sleep(ms){ return new Promise(r=>setTimeout(r, ms)); }

export async function enqueueDiscordLog({ level='info', payload={} }) {
  try {
    await query(
      `INSERT INTO discord_outbox (level, payload) VALUES ($1,$2::jsonb)`,
      [level, JSON.stringify(payload)]
    );
  } catch (e) {
    console.error('enqueueDiscordLog failed', e?.message || e);
  }
}

async function pickOutbox() {
  const r = await query(
    `SELECT id, level, payload, tries
     FROM discord_outbox
     WHERE status IN ('queued','rate_limited') AND (next_try_at IS NULL OR next_try_at <= now())
     ORDER BY created_at ASC
     LIMIT 1`
  );
  return r.rowCount ? r.rows[0] : null;
}

async function updateRow(id, fields) {
  const keys = Object.keys(fields);
  const cols = keys.map((k,i)=>`${k}=$${i+2}`);
  const vals = keys.map(k=>fields[k]);
  await query(`UPDATE discord_outbox SET ${cols.join(',')} WHERE id=$1`, [id, ...vals]);
}

async function sendOnce() {
  const webhook = await getSetting('discord.webhook_url', process.env.DISCORD_LOG_WEBHOOK_URL || '');
  const enabled = String(await getSetting('discord.enabled', process.env.DISCORD_ENABLED || '0')) === '1';
  if (!enabled || !webhook) return;

  const row = await pickOutbox();
  if (!row) return;

  const tries = Number(row.tries || 0) + 1;
  await updateRow(row.id, { status: 'sent', tries }); // optimistic; revert on error

  const body = {
    content: null,
    embeds: [
      {
        title: `DL909 ${row.level.toUpperCase()}`,
        description: '```json\n' + JSON.stringify(row.payload, null, 2).slice(0, 3500) + '\n```'
      }
    ]
  };

  const res = await fetch(webhook, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(body)
  });

  if (res.status === 429) {
    const ra = Number(res.headers.get('retry-after') || '1');
    const next = new Date(Date.now() + Math.max(1000, ra*1000)).toISOString();
    await updateRow(row.id, { status: 'rate_limited', next_try_at: next, last_error: 'rate limited', tries });
    return;
  }

  if (!res.ok) {
    const text = await res.text().catch(()=> '');
    await updateRow(row.id, { status: 'error', last_error: `HTTP ${res.status} ${text}`.slice(0,4000), tries });
    return;
  }

  await updateRow(row.id, { status: 'sent', last_error: null, tries });
}

export function startDiscordOutboxWorker() {
  const enabled = String(process.env.DISCORD_OUTBOX_WORKER_ENABLED || '1') === '1';
  if (!enabled) return;

  const intervalMs = Number(process.env.DISCORD_OUTBOX_POLL_MS || 1500);
  setInterval(() => sendOnce().catch(e => console.error('discord outbox error', e)), intervalMs);
}
