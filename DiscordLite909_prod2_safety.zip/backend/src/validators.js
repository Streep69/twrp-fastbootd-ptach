import { z } from 'zod';

export const RegisterSchema = z.object({
  username: z.string().min(3).max(32).regex(/^[a-zA-Z0-9_\-]+$/),
  password: z.string().min(8).max(128),
  inviteCode: z.string().min(8).max(128)
});

export const LoginSchema = z.object({
  username: z.string().min(3).max(32).regex(/^[a-zA-Z0-9_\-]+$/),
  password: z.string().min(8).max(128)
});

export const CreateServerSchema = z.object({
  name: z.string().min(1).max(64)
});

export const CreateChannelSchema = z.object({
  name: z.string().min(1).max(64),
  type: z.enum(['text','voice'])
});

export const SendMessageSchema = z.object({
  channelId: z.string().uuid(),
  content: z.string().min(1).max(4000)
});

export const LiveKitTokenSchema = z.object({
  room: z.string().min(1).max(128)
});

export const AdminInviteCreateSchema = z.object({
  kind: z.enum(['signup','server']),
  serverId: z.string().uuid().optional(),
  maxUses: z.number().int().min(1).max(100000).default(1),
  expiresInHours: z.number().int().min(1).max(24*365).optional(),
  note: z.string().max(200).optional()
});

export const AdminInviteRevokeSchema = z.object({
  inviteId: z.string().uuid()
});

export const JoinServerByInviteSchema = z.object({
  inviteCode: z.string().min(8).max(128)
});
