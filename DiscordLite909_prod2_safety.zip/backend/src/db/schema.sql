CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  username text UNIQUE NOT NULL,
  pass_hash text NOT NULL,
  is_superadmin boolean NOT NULL DEFAULT false,
  disabled boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS servers (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  name text NOT NULL,
  owner_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS channels (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  server_id uuid NOT NULL REFERENCES servers(id) ON DELETE CASCADE,
  name text NOT NULL,
  type text NOT NULL CHECK (type IN ('text','voice')),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS memberships (
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  server_id uuid NOT NULL REFERENCES servers(id) ON DELETE CASCADE,
  role text NOT NULL DEFAULT 'member',
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, server_id)
);

CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  channel_id uuid NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  content text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Invite-only access control
CREATE TABLE IF NOT EXISTS invites (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  kind text NOT NULL CHECK (kind IN ('signup','server')),
  server_id uuid NULL REFERENCES servers(id) ON DELETE CASCADE,
  code_hash text UNIQUE NOT NULL,
  created_by uuid NULL REFERENCES users(id) ON DELETE SET NULL,
  max_uses integer NOT NULL DEFAULT 1 CHECK (max_uses >= 1 AND max_uses <= 100000),
  uses_count integer NOT NULL DEFAULT 0 CHECK (uses_count >= 0),
  expires_at timestamptz NULL,
  revoked boolean NOT NULL DEFAULT false,
  note text NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS invites_kind_idx ON invites(kind);
CREATE INDEX IF NOT EXISTS invites_server_idx ON invites(server_id);
CREATE INDEX IF NOT EXISTS invites_expires_idx ON invites(expires_at);

CREATE TABLE IF NOT EXISTS invite_uses (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  invite_id uuid NOT NULL REFERENCES invites(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  used_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS invite_uses_invite_idx ON invite_uses(invite_id);


-- ===== 909/999 Production Additions =====

-- Full audit trail (every action)
CREATE TABLE IF NOT EXISTS audit_events (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  ts timestamptz NOT NULL DEFAULT now(),
  actor_user_id uuid NULL REFERENCES users(id) ON DELETE SET NULL,
  actor_username text NULL,
  ip text NULL,
  user_agent text NULL,
  kind text NOT NULL,
  route text NULL,
  method text NULL,
  status integer NULL,
  server_id uuid NULL REFERENCES servers(id) ON DELETE SET NULL,
  channel_id uuid NULL REFERENCES channels(id) ON DELETE SET NULL,
  meta jsonb NOT NULL DEFAULT '{}'::jsonb
);
CREATE INDEX IF NOT EXISTS audit_events_ts_idx ON audit_events(ts DESC);
CREATE INDEX IF NOT EXISTS audit_events_kind_idx ON audit_events(kind);
CREATE INDEX IF NOT EXISTS audit_events_actor_idx ON audit_events(actor_user_id);

-- Encrypted app settings store (superadmin only)
CREATE TABLE IF NOT EXISTS app_settings (
  key text PRIMARY KEY,
  value_enc text NOT NULL,
  updated_at timestamptz NOT NULL DEFAULT now(),
  updated_by uuid NULL REFERENCES users(id) ON DELETE SET NULL
);

-- File uploads (with scanning pipeline)
CREATE TABLE IF NOT EXISTS uploads (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  channel_id uuid NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  filename text NOT NULL,
  mime text NULL,
  size_bytes bigint NOT NULL,
  sha256 text NOT NULL,
  storage_path text NOT NULL,
  status text NOT NULL DEFAULT 'pending' CHECK (status IN ('pending','clean','malicious','blocked','failed','oversize','manual_allow')),
  created_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS uploads_channel_idx ON uploads(channel_id);
CREATE INDEX IF NOT EXISTS uploads_sha_idx ON uploads(sha256);

CREATE TABLE IF NOT EXISTS upload_scans (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  upload_id uuid NOT NULL REFERENCES uploads(id) ON DELETE CASCADE,
  scanner text NOT NULL CHECK (scanner IN ('virustotal')),
  status text NOT NULL DEFAULT 'queued' CHECK (status IN ('queued','uploading','polling','done','error','rate_limited')),
  vt_analysis_id text NULL,
  vt_permalink text NULL,
  result jsonb NOT NULL DEFAULT '{}'::jsonb,
  tries integer NOT NULL DEFAULT 0,
  next_try_at timestamptz NULL,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);
CREATE INDEX IF NOT EXISTS upload_scans_upload_idx ON upload_scans(upload_id);
CREATE INDEX IF NOT EXISTS upload_scans_status_idx ON upload_scans(status);

-- Discord outbound log queue
CREATE TABLE IF NOT EXISTS discord_outbox (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  created_at timestamptz NOT NULL DEFAULT now(),
  level text NOT NULL DEFAULT 'info',
  payload jsonb NOT NULL,
  status text NOT NULL DEFAULT 'queued' CHECK (status IN ('queued','sent','error','rate_limited')),
  tries integer NOT NULL DEFAULT 0,
  next_try_at timestamptz NULL,
  last_error text NULL
);
CREATE INDEX IF NOT EXISTS discord_outbox_status_idx ON discord_outbox(status);

-- Discord inbound events captured by bot (optional)
CREATE TABLE IF NOT EXISTS discord_events (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  ts timestamptz NOT NULL DEFAULT now(),
  guild_id text NULL,
  channel_id text NULL,
  message_id text NULL,
  author_id text NULL,
  author_tag text NULL,
  content text NULL,
  raw jsonb NOT NULL DEFAULT '{}'::jsonb
);
CREATE INDEX IF NOT EXISTS discord_events_ts_idx ON discord_events(ts DESC);
