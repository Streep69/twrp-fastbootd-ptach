import fs from 'node:fs';
import path from 'node:path';
import crypto from 'node:crypto';
import multer from 'multer';
import { query } from './db/pool.js';
import { auditEvent } from './audit.js';
import { requireSuperadminKey } from './superadminGate.js';
import { getSetting } from './settings.js';

const UPLOAD_DIR = process.env.UPLOAD_DIR || '/data/uploads';
fs.mkdirSync(UPLOAD_DIR, { recursive: true });

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOAD_DIR),
  filename: (_req, file, cb) => {
    const safe = String(file.originalname || 'file').replace(/[^a-zA-Z0-9._-]+/g, '_').slice(0, 160);
    const stamp = Date.now().toString(36);
    const rand = crypto.randomBytes(6).toString('hex');
    cb(null, `${stamp}_${rand}_${safe}`);
  }
});

const upload = multer({
  storage,
  limits: { fileSize: Number(process.env.MAX_UPLOAD_BYTES || (100 * 1024 * 1024)) } // 100MB default
});

function sha256File(filePath) {
  const h = crypto.createHash('sha256');
  const s = fs.createReadStream(filePath);
  return new Promise((resolve, reject) => {
    s.on('data', (d) => h.update(d));
    s.on('error', reject);
    s.on('end', () => resolve(h.digest('hex')));
  });
}

async function canAccessChannel(userId, channelId) {
  const r = await query(
    `SELECT 1
     FROM channels c
     JOIN memberships m ON m.server_id=c.server_id
     WHERE c.id=$1 AND m.user_id=$2
     LIMIT 1`,
    [channelId, userId]
  );
  return r.rowCount > 0;
}

export function registerUploadRoutes(app, { authMiddleware, requireSuperadmin }) {
  // list uploads for a channel
  app.get('/api/channels/:channelId/uploads', authMiddleware, async (req, res) => {
    const channelId = req.params.channelId;
    if (!(await canAccessChannel(req.user.id, channelId))) return res.status(403).json({ error: 'no access' });

    const r = await query(
      `SELECT u.id, u.filename, u.mime, u.size_bytes, u.sha256, u.status, u.created_at,
              us.scanner, us.status as scan_status, us.vt_analysis_id, us.result
       FROM uploads u
       LEFT JOIN LATERAL (
         SELECT scanner, status, vt_analysis_id, result
         FROM upload_scans
         WHERE upload_id=u.id
         ORDER BY created_at DESC
         LIMIT 1
       ) us ON true
       WHERE u.channel_id=$1
       ORDER BY u.created_at DESC
       LIMIT 200`,
      [channelId]
    );
    return res.json({ uploads: r.rows });
  });

  // upload file
  app.post('/api/channels/:channelId/uploads', authMiddleware, upload.single('file'), async (req, res) => {
    const channelId = req.params.channelId;
    if (!(await canAccessChannel(req.user.id, channelId))) {
      try { fs.unlinkSync(req.file?.path); } catch {}
      return res.status(403).json({ error: 'no access' });
    }

    const filePath = req.file.path;
    const sizeBytes = req.file.size;
    const sha256 = await sha256File(filePath);

    // default policy: require scan only if enabled
    const requireScan = String(await getSetting('uploads.require_scan', process.env.UPLOADS_REQUIRE_SCAN || '1')) === '1';
    const vtEnabled = String(await getSetting('virustotal.enabled', process.env.VT_ENABLED || '0')) === '1';

    let status = requireScan ? 'pending' : 'clean';

    const ins = await query(
      `INSERT INTO uploads (channel_id, user_id, filename, mime, size_bytes, sha256, storage_path, status)
       VALUES ($1,$2,$3,$4,$5,$6,$7,$8)
       RETURNING id, status`,
      [channelId, req.user.id, req.file.originalname, req.file.mimetype, sizeBytes, sha256, filePath, status]
    );
    const uploadId = ins.rows[0].id;

    await auditEvent({
      kind: 'upload.created',
      actorUserId: req.user.id,
      actorUsername: req.user.username,
      method: req.method,
      route: req.path,
      status: 200,
      channelId,
      meta: { uploadId, filename: req.file.originalname, sha256, sizeBytes, vtEnabled, requireScan }
    });

    // enqueue VT scan if enabled
    if (vtEnabled) {
      await query(
        `INSERT INTO upload_scans (upload_id, scanner, status)
         VALUES ($1,'virustotal','queued')`,
        [uploadId]
      );
    }

    return res.json({ ok: true, upload: { id: uploadId, status: ins.rows[0].status, sha256 } });
  });

  // download
  app.get('/api/uploads/:uploadId/download', authMiddleware, async (req, res) => {
    const uploadId = req.params.uploadId;
    const r = await query(
      `SELECT u.*, c.server_id
       FROM uploads u JOIN channels c ON c.id=u.channel_id
       WHERE u.id=$1`,
      [uploadId]
    );
    if (r.rowCount === 0) return res.status(404).json({ error: 'not found' });

    const u = r.rows[0];
    if (!(await canAccessChannel(req.user.id, u.channel_id))) return res.status(403).json({ error: 'no access' });

    const isSA = !!req.user.is_superadmin;
    const requireScan = String(await getSetting('uploads.require_scan', process.env.UPLOADS_REQUIRE_SCAN || '1')) === '1';

    if (requireScan && !isSA && !['clean','manual_allow'].includes(u.status)) {
      return res.status(423).json({ error: `file not cleared: ${u.status}` });
    }

    await auditEvent({
      kind: 'upload.download',
      actorUserId: req.user.id,
      actorUsername: req.user.username,
      method: req.method,
      route: req.path,
      status: 200,
      channelId: u.channel_id,
      meta: { uploadId, sha256: u.sha256, status: u.status }
    });

    const filename = String(u.filename || 'download.bin').replace(/[\r\n"]/g,'_');
    res.setHeader('Content-Disposition', `attachment; filename="${filename}"`);
    res.setHeader('Content-Type', u.mime || 'application/octet-stream');
    return fs.createReadStream(u.storage_path).pipe(res);
  });

  // superadmin: override allow
  app.post('/api/admin/uploads/:uploadId/allow', authMiddleware, requireSuperadmin, requireSuperadminKey, async (req, res) => {
    const uploadId = req.params.uploadId;
    await query(`UPDATE uploads SET status='manual_allow' WHERE id=$1`, [uploadId]);
    await auditEvent({
      kind: 'upload.manual_allow',
      actorUserId: req.user.id,
      actorUsername: req.user.username,
      method: req.method,
      route: req.path,
      status: 200,
      meta: { uploadId }
    });
    return res.json({ ok: true });
  });

  // superadmin: rescan
  app.post('/api/admin/uploads/:uploadId/rescan', authMiddleware, requireSuperadmin, requireSuperadminKey, async (req, res) => {
    const uploadId = req.params.uploadId;
    const vtEnabled = String(await getSetting('virustotal.enabled', process.env.VT_ENABLED || '0')) === '1';
    if (!vtEnabled) return res.status(400).json({ error: 'virustotal not enabled' });
    await query(`INSERT INTO upload_scans (upload_id, scanner, status) VALUES ($1,'virustotal','queued')`, [uploadId]);
    await query(`UPDATE uploads SET status='pending' WHERE id=$1`, [uploadId]);
    await auditEvent({
      kind: 'upload.rescan',
      actorUserId: req.user.id,
      actorUsername: req.user.username,
      method: req.method,
      route: req.path,
      status: 200,
      meta: { uploadId }
    });
    return res.json({ ok: true });
  });
}
