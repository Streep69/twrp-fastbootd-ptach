import crypto from 'node:crypto';
import { query } from './db/pool.js';

function getSettingsKey() {
  const k = process.env.SETTINGS_ENC_KEY || '';
  if (!k) return null;
  let raw;
  if (/^[0-9a-fA-F]{64}$/.test(k)) raw = Buffer.from(k, 'hex');
  else raw = Buffer.from(k, 'base64');
  if (raw.length !== 32) throw new Error('SETTINGS_ENC_KEY must be 32 bytes (base64 or 64-hex)');
  return raw;
}

function enc(key, plaintext) {
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', key, iv);
  const ct = Buffer.concat([cipher.update(String(plaintext), 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  return `aead:v1:${iv.toString('base64')}:${tag.toString('base64')}:${ct.toString('base64')}`;
}

function dec(key, value) {
  if (!String(value).startsWith('aead:v1:')) return String(value);
  const parts = String(value).split(':');
  if (parts.length !== 5) return String(value);
  const iv = Buffer.from(parts[2], 'base64');
  const tag = Buffer.from(parts[3], 'base64');
  const ct = Buffer.from(parts[4], 'base64');
  const decipher = crypto.createDecipheriv('aes-256-gcm', key, iv);
  decipher.setAuthTag(tag);
  const pt = Buffer.concat([decipher.update(ct), decipher.final()]);
  return pt.toString('utf8');
}

export async function getSetting(key, fallback=null) {
  // env override always wins
  const envKey = `DL909_${String(key).toUpperCase().replace(/[^A-Z0-9]+/g,'_')}`;
  if (process.env[envKey] !== undefined) return process.env[envKey];

  const r = await query('SELECT value_enc FROM app_settings WHERE key=$1', [String(key)]);
  if (r.rowCount === 0) return fallback;

  const k = getSettingsKey();
  if (!k) return r.rows[0].value_enc; // plaintext mode
  return dec(k, r.rows[0].value_enc);
}

export async function setSetting(key, value, updatedBy=null) {
  const k = getSettingsKey();
  const stored = k ? enc(k, value) : String(value);
  await query(
    `INSERT INTO app_settings (key, value_enc, updated_by)
     VALUES ($1,$2,$3)
     ON CONFLICT (key) DO UPDATE SET value_enc=EXCLUDED.value_enc, updated_at=now(), updated_by=EXCLUDED.updated_by`,
    [String(key), stored, updatedBy]
  );
}

export async function listSettings(keys=[]) {
  if (!keys.length) return {};
  const r = await query('SELECT key, value_enc FROM app_settings WHERE key = ANY($1::text[])', [keys]);
  const map = {};
  const k = getSettingsKey();
  for (const row of r.rows) {
    map[row.key] = k ? dec(k, row.value_enc) : row.value_enc;
  }
  return map;
}
