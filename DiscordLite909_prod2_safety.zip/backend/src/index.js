import dotenv from 'dotenv';
dotenv.config();

import express from 'express';
import cors from 'cors';
import bcrypt from 'bcryptjs';
import fs from 'node:fs';
import path from 'node:path';
import { Server } from 'socket.io';
import { createServer } from 'http';

import { query, withTx } from './db/pool.js';
import { signJwt, verifyJwt, authMiddleware, requireSuperadmin, hashInviteCode, randomCode } from './auth.js';
import { makeLiveKitToken } from './livekit.js';
import { requestAuditMiddleware, listAudit } from './audit.js';
import { requireSuperadminKey } from './superadminGate.js';
import { registerUploadRoutes } from './uploads.js';
import { startScanWorker } from './scanners/worker.js';
import { startDiscordOutboxWorker } from './discordOutbox.js';
import { getSetting, setSetting, listSettings } from './settings.js';
import {
  RegisterSchema, LoginSchema,
  CreateServerSchema, CreateChannelSchema,
  SendMessageSchema, LiveKitTokenSchema,
  AdminInviteCreateSchema, AdminInviteRevokeSchema, JoinServerByInviteSchema
} from './validators.js';

const app = express();
app.disable('x-powered-by');
app.use(express.json({ limit: '1mb' }));
app.use(requestAuditMiddleware());

const corsOrigin = process.env.CORS_ORIGIN || 'http://localhost:3000';
app.use(cors({ origin: corsOrigin, credentials: true }));

// basic security headers
app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('Referrer-Policy', 'no-referrer');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Permissions-Policy', 'camera=(self), microphone=(self), geolocation=()');
  next();
});

app.get('/health', (_req, res) => res.json({ ok: true, ts: Date.now() }));

// Discord bot -> backend event ingestion (optional)
app.post('/api/integrations/discord/events', express.json({ limit: '1mb' }), async (req, res) => {
  const secret = process.env.DISCORD_INTEGRATION_SECRET || '';
  const got = (req.headers['x-integration-secret'] || '').toString();
  if (!secret || got !== secret) return res.status(403).json({ error: 'forbidden' });

  const body = req.body || {};
  await query(
    `INSERT INTO discord_events (guild_id, channel_id, message_id, author_id, author_tag, content, raw)
     VALUES ($1,$2,$3,$4,$5,$6,$7::jsonb)`,
    [
      body.guild_id || null,
      body.channel_id || null,
      body.message_id || null,
      body.author_id || null,
      body.author_tag || null,
      body.content || null,
      JSON.stringify(body.raw || body || {})
    ]
  );

  await auditEvent({
    kind: 'discord.event',
    actorUserId: null,
    actorUsername: body.author_tag || null,
    method: 'POST',
    route: '/api/integrations/discord/events',
    status: 200,
    meta: { guild_id: body.guild_id || null, channel_id: body.channel_id || null, message_id: body.message_id || null }
  });

  return res.json({ ok: true });
});


// Uploads + scanning (VirusTotal optional)
registerUploadRoutes(app, { authMiddleware, requireSuperadmin });

// Simple in-memory rate limiter for auth endpoints (per-IP+route)
const rl = new Map(); // key -> { count, resetAt }
function rateLimit({ windowMs=60_000, max=20 } = {}) {
  return (req, res, next) => {
    const ip = (req.headers['x-forwarded-for'] || req.socket.remoteAddress || 'unknown').toString().split(',')[0].trim();
    const key = `${ip}:${req.path}`;
    const now = Date.now();
    const cur = rl.get(key);
    if (!cur || now > cur.resetAt) {
      rl.set(key, { count: 1, resetAt: now + windowMs });
      return next();
    }
    cur.count += 1;
    if (cur.count > max) return res.status(429).json({ error: 'rate limited' });
    return next();
  };
}

function userJwtPayload(u) {
  return { id: u.id, username: u.username, is_superadmin: !!u.is_superadmin };
}

app.get('/api/me', authMiddleware, async (req, res) => {
  const u = await query('SELECT id, username, is_superadmin, disabled FROM users WHERE id=$1', [req.user.id]);
  if (u.rowCount === 0) return res.status(401).json({ error: 'unknown user' });
  const row = u.rows[0];
  if (row.disabled) return res.status(403).json({ error: 'user disabled' });
  return res.json({ user: { id: row.id, username: row.username, is_superadmin: row.is_superadmin } });
});

// Auth (invite-only registration)
app.post('/api/register', rateLimit({ windowMs: 60_000, max: 10 }), async (req, res) => {
  const parsed = RegisterSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json(parsed.error);

  const { username, password, inviteCode } = parsed.data;

  const codeHash = hashInviteCode(inviteCode);

  try {
    const result = await withTx(async (client) => {
      const inv = await client.query(
        `SELECT id, kind, server_id, revoked, max_uses, uses_count, expires_at
         FROM invites
         WHERE code_hash=$1
         FOR UPDATE`,
        [codeHash]
      );
      if (inv.rowCount === 0) return { ok: false, status: 403, body: { error: 'invalid invite' } };

      const invite = inv.rows[0];
      if (invite.revoked) return { ok: false, status: 403, body: { error: 'invite revoked' } };
      if (invite.expires_at && new Date(invite.expires_at).getTime() < Date.now()) return { ok: false, status: 403, body: { error: 'invite expired' } };
      if (invite.uses_count >= invite.max_uses) return { ok: false, status: 403, body: { error: 'invite exhausted' } };
      if (invite.kind !== 'signup') return { ok: false, status: 403, body: { error: 'invite not valid for signup' } };

      const passHash = await bcrypt.hash(password, 12);
      let user;
      try {
        const ins = await client.query(
          'INSERT INTO users (username, pass_hash) VALUES ($1,$2) RETURNING id, username, is_superadmin',
          [username, passHash]
        );
        user = ins.rows[0];
      } catch (e) {
        if (String(e).includes('users_username_key')) {
          return { ok: false, status: 409, body: { error: 'username taken' } };
        }
        throw e;
      }

      await client.query('UPDATE invites SET uses_count = uses_count + 1 WHERE id=$1', [invite.id]);
      await client.query('INSERT INTO invite_uses (invite_id, user_id) VALUES ($1,$2)', [invite.id, user.id]);

      const home = await client.query('SELECT id FROM servers WHERE name=$1 ORDER BY created_at ASC LIMIT 1', ['Home']);
      if (home.rowCount) {
        await client.query(
          'INSERT INTO memberships (user_id, server_id, role) VALUES ($1,$2,$3) ON CONFLICT DO NOTHING',
          [user.id, home.rows[0].id, 'member']
        );
      }

      const token = signJwt(userJwtPayload(user));
      return { ok: true, status: 200, body: { token, user: { id: user.id, username: user.username, is_superadmin: user.is_superadmin } } };
    });

    if (!result.ok) return res.status(result.status).json(result.body);
    return res.json(result.body);
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: 'server error' });
  }
});

app.post('/api/login', rateLimit({ windowMs: 60_000, max: 20 }), async (req, res) => {
  const parsed = LoginSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json(parsed.error);

  const { username, password } = parsed.data;
  const u = await query('SELECT id, username, pass_hash, is_superadmin, disabled FROM users WHERE username=$1', [username]);
  if (u.rowCount === 0) return res.status(401).json({ error: 'invalid credentials' });

  const user = u.rows[0];
  if (user.disabled) return res.status(403).json({ error: 'user disabled' });

  const ok = await bcrypt.compare(password, user.pass_hash);
  if (!ok) return res.status(401).json({ error: 'invalid credentials' });

  const token = signJwt(userJwtPayload(user));
  return res.json({ token, user: { id: user.id, username: user.username, is_superadmin: user.is_superadmin } });
});

// Join a server by invite (logged-in user)
app.post('/api/invites/join', authMiddleware, async (req, res) => {
  const parsed = JoinServerByInviteSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json(parsed.error);
  const { inviteCode } = parsed.data;
  const codeHash = hashInviteCode(inviteCode);

  try {
    const result = await withTx(async (client) => {
      const inv = await client.query(
        `SELECT id, kind, server_id, revoked, max_uses, uses_count, expires_at
         FROM invites WHERE code_hash=$1 FOR UPDATE`,
        [codeHash]
      );
      if (inv.rowCount === 0) return { ok:false, status:404, body:{ error:'invite not found' } };

      const invite = inv.rows[0];
      if (invite.kind !== 'server') return { ok:false, status:400, body:{ error:'invite not for server join' } };
      if (!invite.server_id) return { ok:false, status:400, body:{ error:'invite missing server' } };
      if (invite.revoked) return { ok:false, status:403, body:{ error:'invite revoked' } };
      if (invite.expires_at && new Date(invite.expires_at).getTime() < Date.now()) return { ok:false, status:403, body:{ error:'invite expired' } };
      if (invite.uses_count >= invite.max_uses) return { ok:false, status:403, body:{ error:'invite exhausted' } };

      await client.query(
        'INSERT INTO memberships (user_id, server_id, role) VALUES ($1,$2,$3) ON CONFLICT DO NOTHING',
        [req.user.id, invite.server_id, 'member']
      );

      await client.query('UPDATE invites SET uses_count = uses_count + 1 WHERE id=$1', [invite.id]);
      await client.query('INSERT INTO invite_uses (invite_id, user_id) VALUES ($1,$2)', [invite.id, req.user.id]);

      return { ok:true, status:200, body:{ ok:true, serverId: invite.server_id } };
    });

    if (!result.ok) return res.status(result.status).json(result.body);
    return res.json(result.body);
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: 'server error' });
  }
});

// Servers/channels
app.get('/api/servers', authMiddleware, async (req, res) => {
  const userId = req.user.id;
  const s = await query(
    `SELECT s.id, s.name
     FROM servers s
     JOIN memberships m ON m.server_id=s.id
     WHERE m.user_id=$1
     ORDER BY s.created_at ASC`,
    [userId]
  );
  return res.json({ servers: s.rows });
});

app.post('/api/servers', authMiddleware, async (req, res) => {
  const parsed = CreateServerSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json(parsed.error);

  const userId = req.user.id;
  const { name } = parsed.data;
  const ins = await query('INSERT INTO servers (name, owner_id) VALUES ($1,$2) RETURNING id,name', [name, userId]);
  const server = ins.rows[0];
  await query(
    'INSERT INTO memberships (user_id, server_id, role) VALUES ($1,$2,$3) ON CONFLICT DO NOTHING',
    [userId, server.id, 'owner']
  );
  // create default channels
  await query('INSERT INTO channels (server_id,name,type) VALUES ($1,$2,$3)', [server.id, 'general', 'text']);
  await query('INSERT INTO channels (server_id,name,type) VALUES ($1,$2,$3)', [server.id, 'voice', 'voice']);
  return res.json({ server });
});

app.get('/api/servers/:serverId/channels', authMiddleware, async (req, res) => {
  const userId = req.user.id;
  const { serverId } = req.params;

  const m = await query('SELECT 1 FROM memberships WHERE user_id=$1 AND server_id=$2', [userId, serverId]);
  if (m.rowCount === 0) return res.status(403).json({ error: 'no access' });

  const ch = await query(
    'SELECT id, name, type FROM channels WHERE server_id=$1 ORDER BY created_at ASC',
    [serverId]
  );
  return res.json({ channels: ch.rows });
});

app.post('/api/servers/:serverId/channels', authMiddleware, async (req, res) => {
  const parsed = CreateChannelSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json(parsed.error);

  const userId = req.user.id;
  const { serverId } = req.params;

  const m = await query('SELECT role FROM memberships WHERE user_id=$1 AND server_id=$2', [userId, serverId]);
  if (m.rowCount === 0) return res.status(403).json({ error: 'no access' });

  const { name, type } = parsed.data;
  const ins = await query(
    'INSERT INTO channels (server_id,name,type) VALUES ($1,$2,$3) RETURNING id,name,type',
    [serverId, name, type]
  );
  return res.json({ channel: ins.rows[0] });
});

app.get('/api/channels/:channelId/messages', authMiddleware, async (req, res) => {
  const userId = req.user.id;
  const { channelId } = req.params;

  const ch = await query('SELECT server_id FROM channels WHERE id=$1', [channelId]);
  if (ch.rowCount === 0) return res.status(404).json({ error: 'not found' });

  const serverId = ch.rows[0].server_id;
  const m = await query('SELECT 1 FROM memberships WHERE user_id=$1 AND server_id=$2', [userId, serverId]);
  if (m.rowCount === 0) return res.status(403).json({ error: 'no access' });

  const msgs = await query(
    `SELECT m.id, m.content, m.created_at, u.username, u.id as user_id
     FROM messages m
     JOIN users u ON u.id=m.user_id
     WHERE m.channel_id=$1
     ORDER BY m.created_at DESC
     LIMIT 200`,
    [channelId]
  );
  return res.json({ messages: msgs.rows.reverse() });
});

// LiveKit token for a room (e.g., "serverId:channelId")
app.post('/api/livekit/token', authMiddleware, async (req, res) => {
  const parsed = LiveKitTokenSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json(parsed.error);

  const userId = req.user.id;
  const username = req.user.username;
  const { room } = parsed.data;

  const token = makeLiveKitToken({ userId, username, room });
  const host = process.env.LIVEKIT_HOST || 'http://localhost:7880';

  // LiveKit JS expects ws(s) URL for signaling
  const url = host.replace(/^http:/, 'ws:').replace(/^https:/, 'wss:');
  return res.json({ token, url });
});

// SuperAdmin APIs
let connectedSockets = 0;

app.get('/api/admin/stats', authMiddleware, requireSuperadmin, async (_req, res) => {
  const users = await query('SELECT count(*)::int as n FROM users');
  const servers = await query('SELECT count(*)::int as n FROM servers');
  const channels = await query('SELECT count(*)::int as n FROM channels');
  const messages = await query('SELECT count(*)::int as n FROM messages');
  const invites = await query('SELECT count(*)::int as n FROM invites');
  return res.json({
    ok: true,
    counts: {
      users: users.rows[0].n,
      servers: servers.rows[0].n,
      channels: channels.rows[0].n,
      messages: messages.rows[0].n,
      invites: invites.rows[0].n
    },
    sockets: { connected: connectedSockets },
    env: { corsOrigin }
  });
});

// SuperAdmin settings (toggle safety modules, configure VirusTotal, etc.)
const SAFE_SETTINGS_KEYS = [
  'virustotal.enabled',
  'virustotal.api_key',
  'uploads.require_scan',
  'discord.enabled',
  'discord.webhook_url'
];

app.get('/api/admin/settings', authMiddleware, requireSuperadmin, requireSuperadminKey, async (req, res) => {
  const values = await listSettings(SAFE_SETTINGS_KEYS);
  // Never leak full secrets to UI; show masked form for keys
  const masked = { ...values };
  if (masked['virustotal.api_key']) masked['virustotal.api_key'] = String(masked['virustotal.api_key']).slice(0, 4) + '…' + String(masked['virustotal.api_key']).slice(-4);
  if (masked['discord.webhook_url']) masked['discord.webhook_url'] = '(set)';
  return res.json({ ok: true, settings: masked });
});

app.put('/api/admin/settings', authMiddleware, requireSuperadmin, requireSuperadminKey, async (req, res) => {
  const body = req.body || {};
  for (const k of Object.keys(body)) {
    if (!SAFE_SETTINGS_KEYS.includes(k)) return res.status(400).json({ error: `unknown/blocked key: ${k}` });
  }

  // allow setting secrets explicitly by providing full value
  if (body['virustotal.api_key'] !== undefined) await setSetting('virustotal.api_key', String(body['virustotal.api_key']), req.user.id);
  if (body['virustotal.enabled'] !== undefined) await setSetting('virustotal.enabled', String(body['virustotal.enabled']), req.user.id);

  if (body['uploads.require_scan'] !== undefined) await setSetting('uploads.require_scan', String(body['uploads.require_scan']), req.user.id);

  if (body['discord.enabled'] !== undefined) await setSetting('discord.enabled', String(body['discord.enabled']), req.user.id);
  if (body['discord.webhook_url'] !== undefined) await setSetting('discord.webhook_url', String(body['discord.webhook_url']), req.user.id);

  return res.json({ ok: true });
});

// Audit feed (superadmin)
app.get('/api/admin/audit', authMiddleware, requireSuperadmin, requireSuperadminKey, async (req, res) => {
  const limit = Number(req.query.limit || 200);
  const cursorTs = req.query.cursorTs ? String(req.query.cursorTs) : null;
  const rows = await listAudit({ limit, cursorTs });
  return res.json({ ok: true, events: rows });
});

// Uploads overview (superadmin)
app.get('/api/admin/uploads', authMiddleware, requireSuperadmin, requireSuperadminKey, async (req, res) => {
  const r = await query(
    `SELECT u.id, u.filename, u.mime, u.size_bytes, u.sha256, u.status, u.created_at,
            u.channel_id, u.user_id,
            us.status as scan_status, us.vt_analysis_id, us.result
     FROM uploads u
     LEFT JOIN LATERAL (
       SELECT status, vt_analysis_id, result
       FROM upload_scans
       WHERE upload_id=u.id
       ORDER BY created_at DESC
       LIMIT 1
     ) us ON true
     ORDER BY u.created_at DESC
     LIMIT 500`
  );
  return res.json({ ok: true, uploads: r.rows });
});



app.post('/api/admin/invites/create', authMiddleware, requireSuperadmin, requireSuperadminKey, async (req, res) => {
  const parsed = AdminInviteCreateSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json(parsed.error);

  const { kind, serverId, maxUses, expiresInHours, note } = parsed.data;
  if (kind === 'server' && !serverId) return res.status(400).json({ error: 'serverId required for server invite' });

  const code = randomCode(18);
  const codeHash = hashInviteCode(code);
  const expiresAt = expiresInHours ? new Date(Date.now() + (expiresInHours * 3600 * 1000)).toISOString() : null;

  try {
    const ins = await query(
      `INSERT INTO invites (kind, server_id, code_hash, created_by, max_uses, expires_at, note)
       VALUES ($1,$2,$3,$4,$5,$6,$7)
       RETURNING id, kind, server_id, max_uses, uses_count, expires_at, revoked, created_at`,
      [kind, serverId || null, codeHash, req.user.id, maxUses, expiresAt, note || null]
    );
    return res.json({ invite: ins.rows[0], code });
  } catch (e) {
    console.error(e);
    return res.status(500).json({ error: 'server error' });
  }
});

app.get('/api/admin/invites', authMiddleware, requireSuperadmin, requireSuperadminKey, async (_req, res) => {
  const rows = await query(
    `SELECT id, kind, server_id, max_uses, uses_count, expires_at, revoked, note, created_at
     FROM invites
     ORDER BY created_at DESC
     LIMIT 200`
  );
  return res.json({ invites: rows.rows });
});

app.post('/api/admin/invites/revoke', authMiddleware, requireSuperadmin, requireSuperadminKey, async (req, res) => {
  const parsed = AdminInviteRevokeSchema.safeParse(req.body);
  if (!parsed.success) return res.status(400).json(parsed.error);

  const { inviteId } = parsed.data;
  await query('UPDATE invites SET revoked=true WHERE id=$1', [inviteId]);
  return res.json({ ok: true });
});

// Admin: tail Suricata/Falco logs (optional)
function safeTail(filePath, maxLines=200) {
  try {
    const data = fs.readFileSync(filePath, 'utf8');
    const lines = data.split(/\r?\n/).filter(Boolean);
    return lines.slice(-maxLines);
  } catch {
    return [];
  }
}

app.get('/api/admin/security/suricata', authMiddleware, requireSuperadmin, async (req, res) => {
  const tail = Math.min(Number(req.query.tail || 200), 2000);
  const p = process.env.SURICATA_EVE_PATH || '/security/logs/suricata/eve.json';
  const lines = safeTail(p, tail);
  // Suricata eve.json is JSON-per-line; parse what we can
  const events = [];
  for (const ln of lines) {
    try { events.push(JSON.parse(ln)); } catch {}
  }
  return res.json({ ok: true, path: p, events });
});

app.get('/api/admin/security/falco', authMiddleware, requireSuperadmin, async (req, res) => {
  const tail = Math.min(Number(req.query.tail || 200), 2000);
  const p = process.env.FALCO_LOG_PATH || '/security/logs/falco/falco.json';
  const lines = safeTail(p, tail);
  const events = [];
  for (const ln of lines) {
    try { events.push(JSON.parse(ln)); } catch {}
  }
  return res.json({ ok: true, path: p, events });
});

// Socket.IO (chat)
const httpServer = createServer(app);
const io = new Server(httpServer, {
  cors: { origin: corsOrigin, methods: ['GET','POST'] }
});

// JWT auth for sockets
io.use((socket, next) => {
  const token = socket.handshake.auth?.token;
  if (!token) return next(new Error('missing token'));
  try {
    const user = verifyJwt(token);
    socket.user = user;
    return next();
  } catch {
    return next(new Error('invalid token'));
  }
});

io.on('connection', (socket) => {
  connectedSockets += 1;

  socket.on('disconnect', () => {
    connectedSockets = Math.max(0, connectedSockets - 1);
  });

  socket.on('joinChannel', async ({ channelId }) => {
    if (!channelId) return;
    const ch = await query('SELECT server_id FROM channels WHERE id=$1', [channelId]);
    if (ch.rowCount === 0) return;
    const serverId = ch.rows[0].server_id;
    const m = await query('SELECT 1 FROM memberships WHERE user_id=$1 AND server_id=$2', [socket.user.id, serverId]);
    if (m.rowCount === 0) return;
    socket.join(`channel:${channelId}`);
  });

  socket.on('leaveChannel', ({ channelId }) => {
    if (!channelId) return;
    socket.leave(`channel:${channelId}`);
  });

  socket.on('sendMessage', async (payload, ack) => {
    const parsed = SendMessageSchema.safeParse(payload);
    if (!parsed.success) {
      if (ack) ack({ ok:false, error: parsed.error });
      return;
    }
    const { channelId, content } = parsed.data;

    const ch = await query('SELECT server_id, type FROM channels WHERE id=$1', [channelId]);
    if (ch.rowCount === 0 || ch.rows[0].type !== 'text') {
      if (ack) ack({ ok:false, error: 'invalid channel' });
      return;
    }
    const serverId = ch.rows[0].server_id;
    const m = await query('SELECT 1 FROM memberships WHERE user_id=$1 AND server_id=$2', [socket.user.id, serverId]);
    if (m.rowCount === 0) {
      if (ack) ack({ ok:false, error: 'no access' });
      return;
    }

    const ins = await query(
      'INSERT INTO messages (channel_id,user_id,content) VALUES ($1,$2,$3) RETURNING id,created_at',
      [channelId, socket.user.id, content]
    );

    const msg = {
      id: ins.rows[0].id,
      channelId,
      content,
      created_at: ins.rows[0].created_at,
      user: { id: socket.user.id, username: socket.user.username }
    };

    io.to(`channel:${channelId}`).emit('message', msg);
    if (ack) ack({ ok:true, msg });
  });
});

const port = Number(process.env.PORT || 4000);
httpServer.listen(port, () => console.log(`backend listening on :${port}`));
