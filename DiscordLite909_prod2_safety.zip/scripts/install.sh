#!/usr/bin/env bash
set -euo pipefail

info(){ echo "[909] $*"; }
warn(){ echo "[909][WARN] $*" >&2; }

ROOT="$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)"

if [[ $EUID -ne 0 ]]; then
  warn "Run as root (or use sudo): sudo ./scripts/install.sh"
  exit 1
fi

info "Repo root: $ROOT"

command -v docker >/dev/null 2>&1 || {
  info "Installing Docker Engine (Debian/Ubuntu)…"
  apt-get update
  apt-get install -y ca-certificates curl gnupg
  install -m 0755 -d /etc/apt/keyrings
  curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /etc/apt/keyrings/docker.gpg
  chmod a+r /etc/apt/keyrings/docker.gpg
  echo     "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu     $(. /etc/os-release && echo "$VERSION_CODENAME") stable" | tee /etc/apt/sources.list.d/docker.list > /dev/null
  apt-get update
  apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
}

info "Ensuring env files exist…"
[[ -f "$ROOT/.env" ]] || cp "$ROOT/.env.example" "$ROOT/.env"
[[ -f "$ROOT/backend/.env" ]] || cp "$ROOT/backend/.env.example" "$ROOT/backend/.env"
[[ -f "$ROOT/frontend/.env" ]] || cp "$ROOT/frontend/.env.example" "$ROOT/frontend/.env"

gen_secret(){ python3 - <<'PY'
import secrets, base64
b = secrets.token_bytes(48)
print(base64.urlsafe_b64encode(b).decode().rstrip('='))
PY
}

# Set secrets if placeholders
sed -i -E "s/^JWT_SECRET=.*/JWT_SECRET=$(gen_secret)/" "$ROOT/backend/.env" || true
sed -i -E "s/^INVITE_SALT=.*/INVITE_SALT=$(gen_secret)/" "$ROOT/backend/.env" || true

info "Starting Docker Compose…"
cd "$ROOT"
docker compose up -d --build

info "Done. Open http://localhost:3000 and /admin"
