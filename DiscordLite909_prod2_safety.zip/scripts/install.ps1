param(
  [switch]$SkipDockerInstall = $false
)

Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Write-Info($m){ Write-Host "[909] $m" -ForegroundColor Cyan }
function Write-Warn($m){ Write-Host "[909] $m" -ForegroundColor Yellow }
function Write-Err($m){ Write-Host "[909] $m" -ForegroundColor Red }

function Test-Admin {
  $id = [Security.Principal.WindowsIdentity]::GetCurrent()
  $p = New-Object Security.Principal.WindowsPrincipal($id)
  return $p.IsInRole([Security.Principal.WindowsBuiltInRole]::Administrator)
}

if (-not (Test-Admin)) {
  Write-Err "Please run this script as Administrator (right-click PowerShell -> Run as administrator)."
  exit 1
}

$repoRoot = Split-Path -Parent $MyInvocation.MyCommand.Path
$repoRoot = Resolve-Path (Join-Path $repoRoot "..")

Write-Info "Repo root: $repoRoot"

if (-not $SkipDockerInstall) {
  & (Join-Path $repoRoot "scripts\win\docker_assistant.ps1")
}

function New-Secret([int]$bytes=32) {
  $rng = New-Object System.Security.Cryptography.RNGCryptoServiceProvider
  $b = New-Object byte[]($bytes)
  $rng.GetBytes($b)
  return [Convert]::ToBase64String($b).TrimEnd("=") -replace "\+","-" -replace "/","_"
}


function New-HexSecret([int]$bytes=32) {
  $rng = New-Object System.Security.Cryptography.RNGCryptoServiceProvider
  $b = New-Object byte[]($bytes)
  $rng.GetBytes($b)
  return ($b | ForEach-Object { $_.ToString("x2") }) -join ""
}


# Create env files if missing
if (-not (Test-Path (Join-Path $repoRoot ".env"))) {
  Copy-Item (Join-Path $repoRoot ".env.example") (Join-Path $repoRoot ".env")
  Write-Info "Created .env"
}

if (-not (Test-Path (Join-Path $repoRoot "backend\.env"))) {
  Copy-Item (Join-Path $repoRoot "backend\.env.example") (Join-Path $repoRoot "backend\.env")
  Write-Info "Created backend\.env"
}

if (-not (Test-Path (Join-Path $repoRoot "frontend\.env"))) {
  Copy-Item (Join-Path $repoRoot "frontend\.env.example") (Join-Path $repoRoot "frontend\.env")
  Write-Info "Created frontend\.env"
}

# Ensure strong secrets in backend/.env
$backendEnv = Join-Path $repoRoot "backend\.env"
$lines = Get-Content $backendEnv -ErrorAction Stop

function Set-Or-ReplaceEnvLine([string]$key, [string]$value) {
  $script:lines = $script:lines | ForEach-Object {
    if ($_ -match "^\s*$key=") { return "$key=$value" }
    else { return $_ }
  }
  if (-not ($script:lines | Select-String -SimpleMatch "$key=")) {
    $script:lines += "$key=$value"
  }
}

# Generate secrets if placeholders
if (-not ($lines | Select-String -SimpleMatch "JWT_SECRET=")) { $lines += "JWT_SECRET=" }
if (-not ($lines | Select-String -SimpleMatch "INVITE_SALT=")) { $lines += "INVITE_SALT=" }

$jwt = ($lines | Where-Object { $_ -match "^JWT_SECRET=" }) -replace "^JWT_SECRET=",""
if ([string]::IsNullOrWhiteSpace($jwt) -or $jwt -eq "change-me-super-long") {
  $jwt = New-Secret 48
  Write-Info "Generated JWT_SECRET"
}

$inv = ($lines | Where-Object { $_ -match "^INVITE_SALT=" }) -replace "^INVITE_SALT=",""
if ([string]::IsNullOrWhiteSpace($inv) -or $inv -eq "change-me-too") {
  $inv = New-Secret 48
  Write-Info "Generated INVITE_SALT"
}

$adminUser = ($lines | Where-Object { $_ -match "^BOOTSTRAP_SUPERADMIN_USERNAME=" }) -replace "^BOOTSTRAP_SUPERADMIN_USERNAME=",""
if ([string]::IsNullOrWhiteSpace($adminUser)) { $adminUser = "superadmin" }

$adminPass = ($lines | Where-Object { $_ -match "^BOOTSTRAP_SUPERADMIN_PASSWORD=" }) -replace "^BOOTSTRAP_SUPERADMIN_PASSWORD=",""
if ([string]::IsNullOrWhiteSpace($adminPass)) {
  $adminPass = New-Secret 18
  Write-Info "Generated BOOTSTRAP_SUPERADMIN_PASSWORD"
}

Set-Or-ReplaceEnvLine "JWT_SECRET" $jwt
Set-Or-ReplaceEnvLine "INVITE_SALT" $inv

# Extra hardening keys
if (-not ($lines | Select-String -SimpleMatch "SUPERADMIN_KEY=")) { $lines += "SUPERADMIN_KEY=" }
if (-not ($lines | Select-String -SimpleMatch "SETTINGS_ENC_KEY=")) { $lines += "SETTINGS_ENC_KEY=" }
if (-not ($lines | Select-String -SimpleMatch "MESSAGE_AT_REST_KEY=")) { $lines += "MESSAGE_AT_REST_KEY=" }

$sak = ($lines | Where-Object { $_ -match "^SUPERADMIN_KEY=" }) -replace "^SUPERADMIN_KEY=",""
if ([string]::IsNullOrWhiteSpace($sak) -or $sak -eq "change-this-superadmin-key") {
  $sak = New-Secret 48
  Write-Info "Generated SUPERADMIN_KEY"
}

$sek = ($lines | Where-Object { $_ -match "^SETTINGS_ENC_KEY=" }) -replace "^SETTINGS_ENC_KEY=",""
if ([string]::IsNullOrWhiteSpace($sek)) {
  $sek = New-HexSecret 32
  Write-Info "Generated SETTINGS_ENC_KEY (hex)"
}

$mak = ($lines | Where-Object { $_ -match "^MESSAGE_AT_REST_KEY=" }) -replace "^MESSAGE_AT_REST_KEY=",""
if ([string]::IsNullOrWhiteSpace($mak)) {
  $mak = New-HexSecret 32
  Write-Info "Generated MESSAGE_AT_REST_KEY (hex)"
}

Set-Or-ReplaceEnvLine "SUPERADMIN_KEY" $sak
Set-Or-ReplaceEnvLine "SETTINGS_ENC_KEY" $sek
Set-Or-ReplaceEnvLine "MESSAGE_AT_REST_KEY" $mak

if (-not ($lines | Select-String -SimpleMatch "DISCORD_INTEGRATION_SECRET=")) { $lines += "DISCORD_INTEGRATION_SECRET=" }
$dis = ($lines | Where-Object { $_ -match "^DISCORD_INTEGRATION_SECRET=" }) -replace "^DISCORD_INTEGRATION_SECRET=",""
if ([string]::IsNullOrWhiteSpace($dis)) {
  $dis = New-Secret 48
  Write-Info "Generated DISCORD_INTEGRATION_SECRET"
}
Set-Or-ReplaceEnvLine "DISCORD_INTEGRATION_SECRET" $dis


Set-Or-ReplaceEnvLine "BOOTSTRAP_SUPERADMIN_USERNAME" $adminUser
Set-Or-ReplaceEnvLine "BOOTSTRAP_SUPERADMIN_PASSWORD" $adminPass

Set-Content -Path $backendEnv -Value $lines -Encoding UTF8

Write-Info "Starting Docker Compose (build + up)…"
Push-Location $repoRoot
try {
  docker compose version | Out-Null
  docker compose up -d --build
} finally {
  Pop-Location
}

Write-Info "Done."
Write-Host ""
Write-Host "SuperAdmin login:" -ForegroundColor Green
Write-Host ("  Username: {0}" -f $adminUser) -ForegroundColor Green
Write-Host ("  Password: {0}" -f $adminPass) -ForegroundColor Green
Write-Host ""
Write-Info "Open: http://localhost:3000 and then http://localhost:3000/admin"
