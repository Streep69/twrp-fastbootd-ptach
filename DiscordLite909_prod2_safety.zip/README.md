# DiscordLite909 (909)

Discord-like self-hosted app: **text chat + voice/video + screen share (“Go Live”)** using **LiveKit (WebRTC SFU)**, with **invite-only** registration and a **SuperAdmin Control Room**.

## What you get
- Invite-only accounts (SuperAdmin generates signup invites)
- Optional server join invites (SuperAdmin can generate server invites too)
- Discord-style text channels (Socket.IO)
- Voice/video/screen share per voice channel (LiveKit)
- “Firewall mode”: force TURN relay for users on strict networks
- SuperAdmin Control Room: stats, invite management, optional security event dashboards
- Full audit trail of user actions (DB-backed) + optional Discord mirroring
- File uploads per channel with optional VirusTotal scanning (block downloads until clean)
- Optional Discord bot ingestion (captures Discord channel messages into `discord_events`)
- Tooling:
  - 787: `tools/sandbox787.mjs` (repo validation)
  - 909: `tools/unicode_sanitizer909.mjs` (Trojan Source style bidi/invisible controls)
  - 999: `tools/indexer909.mjs` (deterministic index + vec256 simhash chunks)

## Safety / scanning (optional)
- Upload scanning is controlled by settings:
  - `virustotal.enabled` (0/1)
  - `virustotal.api_key` (stored encrypted via `SETTINGS_ENC_KEY`)
  - `uploads.require_scan` (0/1)
- SuperAdmin key hardening:
  - `SUPERADMIN_KEY` required for admin endpoints
  - `SUPERADMIN_TOTP_SECRET` optional 2FA for admin endpoints


## Framework diagrams (from this chat)
Located in `docs/assets/`:
- `controlroom_mock_909.png`
- `architecture_909.png`
- `topology_909.png`
- `e2ee_flow_909.png`

## Quick start (Docker)
1) Copy env files:
```bash
cp .env.example .env
cp backend/.env.example backend/.env
cp frontend/.env.example frontend/.env
```

2) Set **strong** secrets in `backend/.env`:
- `JWT_SECRET` (random)
- `INVITE_SALT` (random)
- `BOOTSTRAP_SUPERADMIN_PASSWORD` (your password)

3) Start:
```bash
docker compose up --build
```

Open:
- App: http://localhost:3000
- SuperAdmin Control Room: http://localhost:3000/admin
- Backend health: http://localhost:4000/health

## Windows “auto install”
Run from PowerShell (Admin):
```powershell
Set-ExecutionPolicy Bypass -Scope Process -Force
./scripts/install.ps1
```
This will:
- install Docker Desktop + prerequisites (via winget)
- generate strong secrets
- bring up the full stack with Docker Compose
- print your SuperAdmin login info

## Optional security stack (Linux hosts)
For network/runtime security events in the Control Room:
```bash
docker compose -f docker-compose.yml -f docker-compose.security.yml up -d --build
```
This mounts Suricata/Falco logs into the backend (read-only) so the UI can show alerts.

> Note: packet capture IDS typically requires Linux host capabilities. On Windows/macOS this is often limited.

## Production notes
- Put behind HTTPS reverse proxy (Caddy/Nginx/Traefik) and enable WSS.
- Configure ICE/TURN for best connectivity (see `docs/FRAMEWORK_DETAILS_909.md`).
- Prefer a managed TURN or LiveKit Cloud when deploying for lots of users.

## License
MIT
