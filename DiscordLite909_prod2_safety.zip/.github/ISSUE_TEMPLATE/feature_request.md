---
name: Feature request
about: Suggest a feature for DiscordLite909
labels: enhancement
---

## Feature

## Why

## Acceptance criteria
