import { Client, GatewayIntentBits, Partials } from 'discord.js';

const DISCORD_BOT_TOKEN = process.env.DISCORD_BOT_TOKEN || '';
const BACKEND_URL = process.env.BACKEND_URL || 'http://backend:8787';
const INTEGRATION_SECRET = process.env.DISCORD_INTEGRATION_SECRET || '';

if (!DISCORD_BOT_TOKEN) {
  console.error('[909-bot] DISCORD_BOT_TOKEN missing');
  process.exit(1);
}
if (!INTEGRATION_SECRET) {
  console.error('[909-bot] DISCORD_INTEGRATION_SECRET missing');
  process.exit(1);
}

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent
  ],
  partials: [Partials.Channel]
});

async function postEvent(evt) {
  try {
    const res = await fetch(`${BACKEND_URL}/api/integrations/discord/events`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'x-integration-secret': INTEGRATION_SECRET
      },
      body: JSON.stringify(evt)
    });
    if (!res.ok) {
      const t = await res.text().catch(()=> '');
      console.error('[909-bot] backend error', res.status, t);
    }
  } catch (e) {
    console.error('[909-bot] postEvent failed', e?.message || e);
  }
}

client.on('ready', () => {
  console.log(`[909-bot] ready as ${client.user?.tag}`);
});

client.on('messageCreate', async (msg) => {
  // ignore bots
  if (msg.author?.bot) return;

  const evt = {
    guild_id: msg.guildId || null,
    channel_id: msg.channelId || null,
    message_id: msg.id || null,
    author_id: msg.author?.id || null,
    author_tag: msg.author?.tag || null,
    content: msg.content || null,
    ts: new Date().toISOString(),
    raw: {
      attachments: msg.attachments?.map(a => ({ id: a.id, name: a.name, url: a.url, size: a.size })) || []
    }
  };

  await postEvent(evt);

  // optional command: !dl909 ping
  if (msg.content?.trim() === '!dl909 ping') {
    await msg.reply('DL909 bot online ✅');
  }
});

client.login(DISCORD_BOT_TOKEN);
