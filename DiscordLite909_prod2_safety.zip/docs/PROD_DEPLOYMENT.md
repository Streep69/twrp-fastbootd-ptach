# Production deployment notes

## Reverse proxy
Put frontend + backend behind HTTPS. WebRTC needs:
- WSS for signaling
- UDP ports for media (or TCP fallback)

If you terminate TLS at a proxy (Nginx/Caddy/Traefik), forward:
- Frontend: 3000
- Backend: 4000
- LiveKit: 7880 (HTTP/WSS), 7881 (TCP), UDP port range (50000-60000/udp)

## ICE / TURN
For strict networks, TURN improves reachability.
Options:
- LiveKit embedded TURN (enabled in `livekit.yaml`)
- Dedicated TURN service (coturn) on 3478/udp + 443/tcp (common in locked-down networks)
- Managed: LiveKit Cloud or a managed TURN provider

## Hard firewall mode
In the client UI, enable “Force TURN relay” to set ICE policy to relay-only.

## Secrets
Rotate:
- JWT_SECRET
- INVITE_SALT
- LIVEKIT_API_SECRET
