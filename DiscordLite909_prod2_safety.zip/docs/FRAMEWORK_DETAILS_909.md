# DiscordLite909 Framework Details (909)

## Stack
- Frontend: Next.js App Router + React (frontend/)
- Realtime: Socket.IO (chat)
- Streaming: WebRTC via LiveKit (SFU). Optional "force TURN relay" for hard firewalls.
- Backend: Node.js (Express) + Socket.IO + PostgreSQL
- Auth: JWT user sessions + SuperAdmin role gate + invite-only registration

## Streaming modes
- Default: LiveKit SFU (scales well, smooth)
- Clients can optionally force TURN relay to survive strict firewalls (relay-only)

## Security & monitoring
- Unicode sanitizer for Trojan Source style bidi/invisible control characters
- Optional docker-compose.security.yml for Suricata IDS + Falco runtime events (Linux hosts)
- Trivy scans in CI for vulnerabilities/secrets/misconfig
