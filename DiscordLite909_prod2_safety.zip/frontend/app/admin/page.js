'use client';

import { useEffect, useState } from 'react';

const BACKEND = process.env.NEXT_PUBLIC_BACKEND_URL || 'http://localhost:4000';

function api(path, opts = {}) {
  return fetch(`${BACKEND}${path}`, {
    ...opts,
    headers: {
      'Content-Type': 'application/json',
      ...(opts.headers || {}),
    },
  });
}

export default function Admin() {
  const [token, setToken] = useState('');
  const [me, setMe] = useState(null);
  const [saKey, setSaKey] = useState('');
  const [totp, setTotp] = useState('');

  const [stats, setStats] = useState(null);
  const [invites, setInvites] = useState([]);
  const [servers, setServers] = useState([]);

  const [kind, setKind] = useState('signup');
  const [serverId, setServerId] = useState('');
  const [maxUses, setMaxUses] = useState(1);
  const [expiresHours, setExpiresHours] = useState(24 * 30);
  const [note, setNote] = useState('');

  const [createdCode, setCreatedCode] = useState('');
  const [err, setErr] = useState('');

function adminHeaders() {
  const h = { Authorization: `Bearer ${token}` };
  if (saKey) h['x-superadmin-key'] = saKey;
  if (totp) h['x-superadmin-totp'] = totp;
  return h;
}


  const [suricata, setSuricata] = useState([]);
  const [falco, setFalco] = useState([]);

const [settings, setSettings] = useState(null);
const [audit, setAudit] = useState([]);
const [allUploads, setAllUploads] = useState([]);

const [vtKeyInput, setVtKeyInput] = useState('');
const [vtEnabled, setVtEnabled] = useState(false);
const [uploadsRequireScan, setUploadsRequireScan] = useState(true);

const [discordEnabled, setDiscordEnabled] = useState(false);
const [discordWebhook, setDiscordWebhook] = useState('');


  useEffect(() => {
    const saved = localStorage.getItem('dl909_token');
    if (saved) setToken(saved);
    const sk = localStorage.getItem('dl909_sakey');
    if (sk) setSaKey(sk);
    const tp = localStorage.getItem('dl909_totp');
    if (tp) setTotp(tp);
  }, []);


useEffect(() => {
  localStorage.setItem('dl909_sakey', saKey || '');
}, [saKey]);

useEffect(() => {
  localStorage.setItem('dl909_totp', totp || '');
}, [totp]);

  useEffect(() => {
    if (!token) return;
    (async () => {
      const res = await api('/api/me', { headers: { Authorization: `Bearer ${token}` } });
      const data = await res.json();
      if (!res.ok) return setErr(data?.error || 'login required');
      if (!data?.user?.is_superadmin) return setErr('SuperAdmin required');
      setMe(data.user);
    })();
  }, [token]);

  async function refreshAll() {
    if (!token) return;
    setErr('');
    const headers = adminHeaders();
    const [st, inv, sv, su, fa, se, au, up] = await Promise.all([
      api('/api/admin/stats', { headers }),
      api('/api/admin/invites', { headers }),
      api('/api/servers', { headers }),
      api('/api/admin/security/suricata?tail=200', { headers }),
      api('/api/admin/security/falco?tail=200', { headers }),
      api('/api/admin/settings', { headers }),
      api('/api/admin/audit?limit=120', { headers }),
      api('/api/admin/uploads', { headers }),
    ]);
    const stj = await st.json();
    const invj = await inv.json();
    const svj = await sv.json();
    const suj = await su.json();
    const faj = await fa.json();
    const sej = await se.json();
    const auj = await au.json();
    const upj = await up.json();

    if (!st.ok) return setErr(stj?.error || 'failed to load stats');

    setStats(stj);
    setInvites(invj.invites || []);
    setServers(svj.servers || []);
    setSuricata((suj.events || []).slice(-60).reverse());
    setFalco((faj.events || []).slice(-60).reverse());

    if (se.ok) {
      setSettings(sej.settings || null);
      setVtEnabled(String(sej.settings?.['virustotal.enabled'] || '0') === '1');
      setUploadsRequireScan(String(sej.settings?.['uploads.require_scan'] || '1') === '1');
      setDiscordEnabled(String(sej.settings?.['discord.enabled'] || '0') === '1');
      setDiscordWebhook(sej.settings?.['discord.webhook_url'] === '(set)' ? '(set)' : (sej.settings?.['discord.webhook_url'] || ''));
    }
    if (au.ok) setAudit(auj.events || []);
    if (up.ok) setAllUploads(upj.uploads || []);
  }

  useEffect(() => { refreshAll(); }, [token, me?.id]);


async function saveSettings() {
  setErr('');
  try {
    const headers = adminHeaders();
    const body = {
      'virustotal.enabled': vtEnabled ? '1' : '0',
      'uploads.require_scan': uploadsRequireScan ? '1' : '0',
      'discord.enabled': discordEnabled ? '1' : '0',
    };
    if (vtKeyInput) body['virustotal.api_key'] = vtKeyInput.trim();
    if (discordWebhook && discordWebhook !== '(set)') body['discord.webhook_url'] = discordWebhook.trim();
    const res = await api('/api/admin/settings', { method:'PUT', headers, body: JSON.stringify(body) });
    const data = await res.json();
    if (!res.ok) throw new Error(data?.error || 'save failed');
    setVtKeyInput('');
    await refreshAll();
  } catch (e) {
    setErr(String(e?.message || e));
  }
}

async function allowUpload(id) {
  setErr('');
  try {
    const headers = adminHeaders();
    const res = await api(`/api/admin/uploads/${id}/allow`, { method:'POST', headers, body: JSON.stringify({}) });
    const data = await res.json();
    if (!res.ok) throw new Error(data?.error || 'allow failed');
    await refreshAll();
  } catch (e) {
    setErr(String(e?.message || e));
  }
}

async function rescanUpload(id) {
  setErr('');
  try {
    const headers = adminHeaders();
    const res = await api(`/api/admin/uploads/${id}/rescan`, { method:'POST', headers, body: JSON.stringify({}) });
    const data = await res.json();
    if (!res.ok) throw new Error(data?.error || 'rescan failed');
    await refreshAll();
  } catch (e) {
    setErr(String(e?.message || e));
  }
}

  async function createInvite() {
    setErr('');
    setCreatedCode('');
    try {
      const headers = adminHeaders();
      const body = {
        kind,
        maxUses: Number(maxUses),
        expiresInHours: Number(expiresHours),
        note: note || undefined,
        ...(kind === 'server' ? { serverId } : {})
      };
      const res = await api('/api/admin/invites/create', { method:'POST', headers, body: JSON.stringify(body) });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || 'create failed');
      setCreatedCode(data.code);
      await refreshAll();
    } catch (e) {
      setErr(String(e?.message || e));
    }
  }

  async function revoke(inviteId) {
    setErr('');
    try {
      const headers = adminHeaders();
      const res = await api('/api/admin/invites/revoke', { method:'POST', headers, body: JSON.stringify({ inviteId }) });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || 'revoke failed');
      await refreshAll();
    } catch (e) {
      setErr(String(e?.message || e));
    }
  }

  if (err && !me) {
    return (
      <div style={wrap}>
        <h2 style={{ marginTop: 0 }}>SuperAdmin Control Room</h2>
        <div style={{ color:'#ff6b6b', marginTop: 10 }}>{err}</div>
        <div style={{ marginTop: 10, color:'#9aa4b2' }}>
          Open the main app, login as SuperAdmin, then return here.
        </div>
        <div style={{ marginTop: 14 }}>
          <a href="/" style={{ color:'#9ad' }}>Back to app</a>
        </div>
      </div>
    );
  }

  return (
    <div style={wrap}>
      <div style={{ display:'flex', justifyContent:'space-between', alignItems:'baseline', gap: 12 }}>
        <div>
          <h2 style={{ margin: 0 }}>SuperAdmin Control Room</h2>
          <div style={{ color:'#9aa4b2', marginTop: 6 }}>
            Logged in as <b style={{ color:'#fff' }}>{me?.username}</b>
          </div>
        </div>
        <div style={{ display:'flex', gap: 10 }}>
          <button onClick={refreshAll} style={btn}>Refresh</button>


<div style={{ marginTop: 12, padding: 12, border: '1px solid #222', borderRadius: 16, background:'#0b0d11' }}>
  <div style={{ fontWeight: 800, marginBottom: 8 }}>Safety Settings</div>

  <div style={{ display:'flex', gap: 10, flexWrap:'wrap', alignItems:'center' }}>
    <label style={{ fontSize: 12, color:'#cdd6f4' }}>
      <input type="checkbox" checked={vtEnabled} onChange={(e)=>setVtEnabled(e.target.checked)} /> VirusTotal (uploads scanning)
    </label>
    <label style={{ fontSize: 12, color:'#cdd6f4' }}>
      <input type="checkbox" checked={uploadsRequireScan} onChange={(e)=>setUploadsRequireScan(e.target.checked)} /> Block downloads until clean
    </label>
    <label style={{ fontSize: 12, color:'#cdd6f4' }}>
      <input type="checkbox" checked={discordEnabled} onChange={(e)=>setDiscordEnabled(e.target.checked)} /> Mirror audit to Discord webhook
    </label>
  </div>

  <div style={{ display:'flex', gap: 10, marginTop: 10, flexWrap:'wrap' }}>
    <input value={vtKeyInput} onChange={(e)=>setVtKeyInput(e.target.value)} placeholder="VirusTotal API key (paste to set/update)" style={{ flex: 2, minWidth: 240, padding: 10, borderRadius: 12, border:'1px solid #222', background:'#0f1115', color:'#e8e8e8' }} />
    <input value={discordWebhook} onChange={(e)=>setDiscordWebhook(e.target.value)} placeholder="Discord webhook URL (optional)" style={{ flex: 2, minWidth: 240, padding: 10, borderRadius: 12, border:'1px solid #222', background:'#0f1115', color:'#e8e8e8' }} />
    <button onClick={saveSettings} style={{ padding:'10px 12px', borderRadius: 12, border:'1px solid #222', background:'#141822', color:'#e8e8e8', cursor:'pointer' }}>
      Save settings
    </button>
  </div>

  {settings ? <div style={{ fontSize: 12, color:'#9aa4b2', marginTop: 8 }}>Current: VT={String(settings['virustotal.enabled']||'0')} · uploads.require_scan={String(settings['uploads.require_scan']||'1')}</div> : null}
</div>

<div style={{ marginTop: 12, display:'grid', gridTemplateColumns:'1fr 1fr', gap: 12 }}>
  <div style={{ padding: 12, border:'1px solid #222', borderRadius: 16, background:'#0b0d11', minHeight: 260 }}>
    <div style={{ fontWeight: 800, marginBottom: 8 }}>Recent Audit</div>
    <div style={{ maxHeight: 240, overflow:'auto', fontSize: 12 }}>
      {(audit || []).map((e) => (
        <div key={e.id} style={{ padding:'6px 0', borderBottom:'1px solid #12151d' }}>
          <div><b>{e.kind}</b> <span style={{ color:'#778' }}>{new Date(e.ts).toLocaleString()}</span></div>
          <div style={{ color:'#9aa4b2' }}>{e.actor_username || 'system'} · {e.route || ''} · {e.status || ''}</div>
        </div>
      ))}
      {!audit?.length ? <div style={{ color:'#778' }}>No audit events yet.</div> : null}
    </div>
  </div>

  <div style={{ padding: 12, border:'1px solid #222', borderRadius: 16, background:'#0b0d11', minHeight: 260 }}>
    <div style={{ fontWeight: 800, marginBottom: 8 }}>Uploads (latest)</div>
    <div style={{ maxHeight: 240, overflow:'auto', fontSize: 12 }}>
      {(allUploads || []).slice(0, 60).map((u) => (
        <div key={u.id} style={{ padding:'6px 0', borderBottom:'1px solid #12151d', display:'flex', gap: 8, alignItems:'center' }}>
          <div style={{ flex:1, minWidth: 0 }}>
            <div style={{ whiteSpace:'nowrap', overflow:'hidden', textOverflow:'ellipsis' }}>{u.filename}</div>
            <div style={{ color:'#9aa4b2' }}>{u.status} · scan:{u.scan_status || 'n/a'}</div>
          </div>
          <button onClick={()=>rescanUpload(u.id)} style={{ padding:'6px 8px', borderRadius: 10, border:'1px solid #222', background:'#0f1115', color:'#e8e8e8', cursor:'pointer' }}>Rescan</button>
          <button onClick={()=>allowUpload(u.id)} style={{ padding:'6px 8px', borderRadius: 10, border:'1px solid #222', background:'#141822', color:'#e8e8e8', cursor:'pointer' }}>Allow</button>
        </div>
      ))}
      {!allUploads?.length ? <div style={{ color:'#778' }}>No uploads yet.</div> : null}
    </div>
  </div>
</div>

          <a href="/" style={{ color:'#9ad', alignSelf:'center' }}>Back</a>
        </div>
      </div>

      {stats ? (
        <div style={{ display:'grid', gridTemplateColumns:'repeat(6, minmax(0, 1fr))', gap: 10, marginTop: 16 }}>
          <Card label="Users" value={stats.counts.users} />
          <Card label="Servers" value={stats.counts.servers} />
          <Card label="Channels" value={stats.counts.channels} />
          <Card label="Messages" value={stats.counts.messages} />
          <Card label="Invites" value={stats.counts.invites} />
          <Card label="Sockets" value={stats.sockets.connected} />
        </div>
      ) : null}

      <div style={grid2}>
        <div style={panel}>
          <h3 style={h3}>Create invite</h3>
          <div style={{ display:'grid', gridTemplateColumns:'1fr 1fr', gap: 10 }}>
            <label style={lbl}>
              Kind
              <select value={kind} onChange={(e)=>setKind(e.target.value)} style={sel}>
                <option value="signup">Signup invite (new account)</option>
                <option value="server">Server invite (join server)</option>
              </select>
            </label>
            <label style={lbl}>
              Max uses
              <input value={maxUses} onChange={(e)=>setMaxUses(e.target.value)} style={inp} />
            </label>
            <label style={lbl}>
              Expires in hours
              <input value={expiresHours} onChange={(e)=>setExpiresHours(e.target.value)} style={inp} />
            </label>
            <label style={lbl}>
              Server (for server invites)
              <select value={serverId} onChange={(e)=>setServerId(e.target.value)} style={sel} disabled={kind !== 'server'}>
                <option value="">Select server…</option>
                {servers.map(s => <option key={s.id} value={s.id}>{s.name}</option>)}
              </select>
            </label>
            <label style={{ ...lbl, gridColumn:'1 / -1' }}>
              Note
              <input value={note} onChange={(e)=>setNote(e.target.value)} style={inp} />
            </label>
          </div>
          <button onClick={createInvite} style={{ ...btn, marginTop: 10 }}>Create</button>
          {createdCode ? (
            <div style={{ marginTop: 10, padding: 12, background:'#0b0d11', border:'1px solid #222', borderRadius: 12 }}>
              <div style={{ color:'#9aa4b2', fontSize: 12 }}>Invite code (copy now; stored hashed server-side)</div>
              <div style={{ fontFamily:'ui-monospace, SFMono-Regular, Menlo, Monaco, Consolas, "Liberation Mono", "Courier New", monospace', marginTop: 6, fontSize: 16 }}>
                {createdCode}
              </div>
            </div>
          ) : null}
          {err ? <div style={{ color:'#ff6b6b', marginTop: 10 }}>{err}</div> : null}
        </div>

        <div style={panel}>
          <h3 style={h3}>Invites (latest 200)</h3>
          <div style={{ maxHeight: 360, overflow:'auto', border:'1px solid #222', borderRadius: 12 }}>
            <table style={{ width:'100%', borderCollapse:'collapse', fontSize: 12 }}>
              <thead style={{ position:'sticky', top:0, background:'#0b0d11' }}>
                <tr>
                  <th style={th}>Kind</th>
                  <th style={th}>Uses</th>
                  <th style={th}>Expires</th>
                  <th style={th}>Revoked</th>
                  <th style={th}>Note</th>
                  <th style={th}></th>
                </tr>
              </thead>
              <tbody>
                {invites.map(i => (
                  <tr key={i.id} style={{ borderTop:'1px solid #222' }}>
                    <td style={td}>{i.kind}</td>
                    <td style={td}>{i.uses_count} / {i.max_uses}</td>
                    <td style={td}>{i.expires_at ? new Date(i.expires_at).toLocaleString() : '—'}</td>
                    <td style={td}>{i.revoked ? 'yes' : 'no'}</td>
                    <td style={td}>{i.note || '—'}</td>
                    <td style={td}>
                      {!i.revoked ? <button onClick={() => revoke(i.id)} style={tinyBtn}>Revoke</button> : null}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
          <div style={{ marginTop: 10, color:'#9aa4b2', fontSize: 12 }}>
            Tip: Signup invites allow new accounts. Server invites let existing accounts join a server.
          </div>
        </div>
      </div>

      <div style={grid2}>
        <div style={panel}>
          <h3 style={h3}>Suricata IDS (optional)</h3>
          <div style={{ color:'#9aa4b2', fontSize: 12, marginBottom: 8 }}>
            Shows recent network alerts if docker-compose.security.yml is running and logs are mounted.
          </div>
          <LogTable rows={suricata} kind="suricata" />
        </div>
        <div style={panel}>
          <h3 style={h3}>Falco runtime events (optional)</h3>
          <div style={{ color:'#9aa4b2', fontSize: 12, marginBottom: 8 }}>
            Shows recent runtime security events if Falco is enabled and logs are mounted.
          </div>
          <LogTable rows={falco} kind="falco" />
        </div>
      </div>

      <div style={{ marginTop: 14, color:'#9aa4b2', fontSize: 12 }}>
        Framework diagrams: see <code>docs/assets/</code> in the repo.
      </div>
    </div>
  );
}

function Card({ label, value }) {
  return (
    <div style={{ border:'1px solid #222', background:'#0b0d11', borderRadius: 14, padding: 12 }}>
      <div style={{ color:'#9aa4b2', fontSize: 12 }}>{label}</div>
      <div style={{ fontSize: 26, fontWeight: 900, marginTop: 2 }}>{value}</div>
    </div>
  );
}

function LogTable({ rows, kind }) {
  return (
    <div style={{ maxHeight: 320, overflow:'auto', border:'1px solid #222', borderRadius: 12, background:'#0b0d11' }}>
      <table style={{ width:'100%', borderCollapse:'collapse', fontSize: 12 }}>
        <thead style={{ position:'sticky', top:0, background:'#0b0d11' }}>
          <tr>
            <th style={th}>Time</th>
            <th style={th}>Type</th>
            <th style={th}>Summary</th>
          </tr>
        </thead>
        <tbody>
          {rows.length ? rows.map((e, idx) => (
            <tr key={idx} style={{ borderTop:'1px solid #222' }}>
              <td style={td}>{extractTime(e) || '—'}</td>
              <td style={td}>{extractType(e, kind)}</td>
              <td style={td}>{extractSummary(e, kind)}</td>
            </tr>
          )) : (
            <tr><td style={td} colSpan={3}>(no events)</td></tr>
          )}
        </tbody>
      </table>
    </div>
  );
}

function extractTime(e) {
  return e?.timestamp ? new Date(e.timestamp).toLocaleString() : (e?.time ? new Date(e.time).toLocaleString() : '');
}
function extractType(e, kind) {
  if (kind === 'suricata') return e?.event_type || 'event';
  if (kind === 'falco') return e?.rule || e?.priority || 'event';
  return 'event';
}
function extractSummary(e, kind) {
  if (kind === 'suricata') return e?.alert?.signature || e?.alert?.category || JSON.stringify(e).slice(0, 160);
  if (kind === 'falco') return e?.output || JSON.stringify(e).slice(0, 160);
  return JSON.stringify(e).slice(0, 160);
}

const wrap = { maxWidth: 1200, margin: '40px auto', padding: 18, color:'#e8e8e8', background:'#0f1115' };
const grid2 = { display:'grid', gridTemplateColumns:'1fr 1fr', gap: 12, marginTop: 16 };
const panel = { border:'1px solid #222', background:'#11151c', borderRadius: 16, padding: 14 };
const h3 = { marginTop: 0, marginBottom: 10 };
const lbl = { display:'flex', flexDirection:'column', gap: 6, fontSize: 12, color:'#9aa4b2' };
const inp = { padding: 10, borderRadius: 10, border:'1px solid #222', background:'#0b0d11', color:'#e8e8e8' };
const sel = { padding: 10, borderRadius: 10, border:'1px solid #222', background:'#0b0d11', color:'#e8e8e8' };
const btn = { padding:'10px 12px', borderRadius: 12, border:'1px solid #222', background:'#0b0d11', color:'#e8e8e8', cursor:'pointer' };
const tinyBtn = { padding:'6px 8px', borderRadius: 10, border:'1px solid #222', background:'#0f1115', color:'#e8e8e8', cursor:'pointer' };
const th = { textAlign:'left', padding:'10px 10px', color:'#9aa4b2' };
const td = { padding:'10px 10px', verticalAlign:'top' };
