# Control Room (Superadmin)

## What it can do
- View global stats
- Create/revoke invite codes
- Inspect:
  - audit trail
  - inbound Discord events
  - webhook outbox delivery queue
  - Suricata + Falco logs (if enabled)

## Required headers
All admin endpoints require:
- JWT token (Authorization: Bearer ...)
- `x-superadmin-key: SUPERADMIN_KEY`

Optional:
- If `SUPERADMIN_TOTP_SECRET` is set:
  - `x-superadmin-totp: 123456`

The `/admin` UI lets you paste these values once.
