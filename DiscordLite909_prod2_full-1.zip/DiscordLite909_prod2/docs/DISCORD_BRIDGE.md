# Discord bridge

## Outbound (webhook)
Set in `backend/.env`:
- `DISCORD_LOG_WEBHOOK_URL=<your webhook url>`
- `DISCORD_LOG_MIN_LEVEL=info`

The backend writes webhook payloads into `discord_outbox`.
A worker drains the outbox and retries with backoff (rate-limit aware).

## Inbound (bot)
Enable the compose profile:
- `docker compose -f docker-compose.yml up -d --profile discord --build`

Set in `backend/.env`:
- `DISCORD_BOT_TOKEN=...`
- `DISCORD_GUILD_ID=...`
- `DISCORD_WATCH_CHANNEL_IDS=123,456,...`

Inbound messages are stored in `discord_events` and visible in the Control Room.
