# Production install (Linux)

## DNS + firewall requirements
Before you run the installer:
- Point DNS A/AAAA records to your server:
  - `app.<domain>`
  - `api.<domain>`
  - `lk.<domain>`
- Open ports:
  - 80/tcp, 443/tcp, 443/udp (Caddy HTTPS + HTTP/3)
  - 7881/tcp (LiveKit TCP fallback)
  - 3478/udp (TURN UDP)
  - 5349/tcp (TURN TLS, optional)
  - 50000-60000/udp (LiveKit media)

## One command
From the repo directory:

```bash
sudo bash scripts/prod/install-linux-production.sh --domain example.com --email admin@example.com
```

Optional:
- `--enable-security` (Suricata + Falco)
- `--enable-discord` (Discord bot service)

## After install
- Open the app: `https://app.<domain>`
- Control Room: `https://app.<domain>/admin`
- SUPERADMIN_KEY is generated into `backend/.env`

## Windows host install
Run as Admin:

```powershell
powershell -ExecutionPolicy Bypass -File scripts\prod\install-windows-production.ps1 -Domain example.com -Email admin@example.com
```

You must start Docker Desktop once before the script can run the compose stack.
