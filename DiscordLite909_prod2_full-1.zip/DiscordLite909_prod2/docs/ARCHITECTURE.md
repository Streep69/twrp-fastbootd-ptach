# DiscordLite909 — Architecture

## What this is
A self-hosted, invite-only, Discord-like app with:
- Text chat (servers, channels, messages)
- Voice/video + screen share streaming (WebRTC via LiveKit)
- Optional Security Sensors (Suricata + Falco)
- Superadmin Control Room (Overwatch) with full audit trail
- Optional Discord bridge:
  - **Outbound**: webhook delivery queue (DB outbox -> Discord webhook)
  - **Inbound**: bot ingests selected Discord channels into the DB

## Services (Docker Compose)

### postgres
Stores all persistent data:
- users, servers, channels, messages
- invites (invite-only access)
- **audit_events** (everything every user does)
- **discord_events** (inbound bot events)
- **discord_outbox** (webhook delivery queue)

### redis
Used for ephemeral tasks / realtime helpers.

### backend (Node/Express + Socket.IO)
- REST API under `/api/*`
- Socket.IO realtime channel traffic
- JWT auth + invite gating
- **At-rest encryption** for message content (AES-256-GCM) if `MESSAGE_AT_REST_KEY` is set
- **Superadmin overwatch**: admin endpoints require both:
  1) user is flagged `is_superadmin=true`
  2) request header `x-superadmin-key: SUPERADMIN_KEY`
  3) optional header `x-superadmin-totp` if `SUPERADMIN_TOTP_SECRET` is set

### livekit
WebRTC SFU that handles voice/video/screen-share.
- TCP signaling is proxied via Caddy in production
- UDP media ports are exposed directly (required)

### frontend (Next.js)
- Web client UI
- `/admin` = Control Room (superadmin)

### caddy (production only)
Reverse proxy + automatic HTTPS:
- `app.<domain>` -> frontend
- `api.<domain>` -> backend
- `lk.<domain>` -> livekit

### discordbot (optional profile `discord`)
Separate process using `discord.js`:
- watches configured channels
- stores inbound messages into `discord_events`

### security sensors (optional)
- Suricata (network IDS)
- Falco (runtime security detection)

## “Superadmin overwatch” model

There are **two layers**:
1) **Identity** (JWT + DB flag `is_superadmin`)
2) **Possession** (secret `SUPERADMIN_KEY`, plus optional TOTP)

This makes “admin token theft” insufficient by itself.

## Invite-only model
All account creation is gated by invite codes:
- signup invites for new users
- server invites for joining a server

## Audit trail
The backend logs:
- all API calls (HTTP scope)
- key socket events (join + send message)
into `audit_events`.

The Control Room can view the feed.
Optionally, events can also be forwarded to Discord via a webhook outbox.
