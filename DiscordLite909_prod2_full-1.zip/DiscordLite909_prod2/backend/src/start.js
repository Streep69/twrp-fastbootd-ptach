import dotenv from 'dotenv';
dotenv.config();

import { initDbIfNeeded } from './db/init.js';
import { startDiscordOutboxWorker } from './discordWebhook.js';

try {
  await initDbIfNeeded();
startDiscordOutboxWorker();
} catch (e) {
  console.error('Startup DB init failed:', e);
  process.exit(1);
}

// start HTTP server after DB ready
await import('./index.js');
