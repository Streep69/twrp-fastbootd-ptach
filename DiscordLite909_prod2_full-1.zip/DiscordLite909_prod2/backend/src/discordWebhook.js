import { query } from './db/pool.js';

const WEBHOOK = process.env.DISCORD_LOG_WEBHOOK_URL || '';
const MIN_LEVEL = (process.env.DISCORD_LOG_MIN_LEVEL || 'info').toLowerCase();
const ENABLE = !!WEBHOOK;

const LEVELS = { debug: 10, info: 20, warn: 30, error: 40 };
function levelOk(level) {
  const a = LEVELS[String(level||'info').toLowerCase()] ?? 20;
  const b = LEVELS[MIN_LEVEL] ?? 20;
  return a >= b;
}

export function discordLogPayload({ level='info', title='DiscordLite909', fields=[] }) {
  return {
    username: 'DiscordLite909',
    embeds: [{
      title,
      description: `level: **${level}**`,
      fields: fields.map(f => ({ name: String(f.name), value: String(f.value).slice(0, 1000), inline: !!f.inline })),
      timestamp: new Date().toISOString(),
    }]
  };
}

export async function enqueueDiscord(payload, { level='info' } = {}) {
  if (!ENABLE) return;
  if (!levelOk(level)) return;
  await query(
    `INSERT INTO discord_outbox (payload, attempts, next_attempt_at)
     VALUES ($1, 0, now())`,
    [payload]
  );
}

async function sendOnce(row) {
  const url = WEBHOOK;
  const body = row.payload;

  const res = await fetch(url, {
    method: 'POST',
    headers: { 'Content-Type':'application/json' },
    body: JSON.stringify(body),
  });

  if (res.status === 204 || (res.status >= 200 && res.status < 300)) {
    await query('DELETE FROM discord_outbox WHERE id=$1', [row.id]);
    return;
  }

  // rate limited
  if (res.status === 429) {
    let retrySec = 5;
    try {
      const j = await res.json();
      if (typeof j.retry_after === 'number') retrySec = Math.max(1, Math.ceil(j.retry_after));
    } catch {}
    const hdr = res.headers.get('Retry-After');
    if (hdr && /^[0-9.]+$/.test(hdr)) retrySec = Math.max(retrySec, Math.ceil(parseFloat(hdr)));

    await query(
      `UPDATE discord_outbox
         SET attempts = attempts + 1,
             last_status = $2,
             last_error = $3,
             last_attempt_at = now(),
             next_attempt_at = now() + ($4 || ' seconds')::interval
       WHERE id=$1`,
      [row.id, res.status, 'rate_limited', String(retrySec)]
    );
    return;
  }

  const txt = await res.text().catch(() => '');
  const err = (txt || '').slice(0, 500);
  // exponential backoff (cap at 15 min)
  const attempts = Number(row.attempts || 0) + 1;
  const delay = Math.min(900, Math.max(5, 2 ** Math.min(10, attempts)));
  await query(
    `UPDATE discord_outbox
       SET attempts = attempts + 1,
           last_status = $2,
           last_error = $3,
           last_attempt_at = now(),
           next_attempt_at = now() + ($4 || ' seconds')::interval
     WHERE id=$1`,
    [row.id, res.status, err || 'webhook_error', String(delay)]
  );
}

export function startDiscordOutboxWorker() {
  if (!ENABLE) return;
  const intervalMs = Number(process.env.DISCORD_OUTBOX_POLL_MS || 2000);
  setInterval(async () => {
    try {
      const r = await query(
        `SELECT id, payload, attempts
           FROM discord_outbox
          WHERE next_attempt_at <= now()
          ORDER BY created_at ASC
          LIMIT 5`
      );
      for (const row of r.rows) {
        await sendOnce(row);
      }
    } catch {
      // ignore
    }
  }, intervalMs);
}
