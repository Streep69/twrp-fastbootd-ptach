import { query } from './db/pool.js';
import { sha256Text } from './cryptoAtRest.js';

function safeJson(obj) {
  try { return JSON.stringify(obj ?? {}); } catch { return '{}'; }
}

function redactBody(body) {
  if (!body || typeof body !== 'object') return body;
  const clone = Array.isArray(body) ? body.slice() : { ...body };
  const redactKeys = new Set(['password', 'pass', 'pass_hash', 'token', 'authorization', 'secret', 'apiKey', 'apiSecret']);
  for (const k of Object.keys(clone)) {
    const lk = k.toLowerCase();
    if (redactKeys.has(lk) || lk.includes('password') || lk.includes('secret') || lk.includes('token')) {
      clone[k] = '[redacted]';
    }
  }
  return clone;
}

export async function insertAuditEvent({
  userId = null,
  action,
  scope = 'app',
  meta = {},
  ip = null,
  ua = null,
}) {
  await query(
    `INSERT INTO audit_events (user_id, scope, action, meta, ip, user_agent)
     VALUES ($1,$2,$3,$4,$5,$6)`,
    [userId, scope, action, meta, ip, ua]
  );
}

export function requestAuditMiddleware({ skipPaths = [] } = {}) {
  const skip = new Set(skipPaths);
  return (req, res, next) => {
    const start = Date.now();
    res.on('finish', async () => {
      try {
        const p = req.path || req.url || '';
        if (!p.startsWith('/api')) return;
        if (skip.has(p)) return;
        if (p.startsWith('/api/admin/security/')) return; // noisy
        const durMs = Date.now() - start;
        const userId = req.user?.id || null;
        const body = redactBody(req.body);
        const meta = {
          method: req.method,
          path: p,
          status: res.statusCode,
          durMs,
          bodyHash: sha256Text(safeJson(body)),
        };
        await insertAuditEvent({
          userId,
          action: 'http',
          scope: 'http',
          meta,
          ip: req.headers['x-forwarded-for']?.toString()?.split(',')[0]?.trim() || req.socket?.remoteAddress || null,
          ua: req.headers['user-agent'] || null,
        });
      } catch {
        // never break requests due to audit
      }
    });
    next();
  };
}
