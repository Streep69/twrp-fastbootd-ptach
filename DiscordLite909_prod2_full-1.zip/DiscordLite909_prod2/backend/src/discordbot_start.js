import dotenv from 'dotenv';
dotenv.config();

import { initDbIfNeeded } from './db/init.js';

try {
  await initDbIfNeeded();
} catch (e) {
  console.error('[discordbot] DB init failed:', e);
  process.exit(1);
}

await import('./discordbot.js');
