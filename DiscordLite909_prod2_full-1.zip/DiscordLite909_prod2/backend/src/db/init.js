import fs from 'fs';
import path from 'path';
import { fileURLToPath } from 'url';
import bcrypt from 'bcryptjs';
import crypto from 'node:crypto';
import { pool, query } from './pool.js';

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

function readSchema() {
  const p = path.join(__dirname, 'schema.sql');
  return fs.readFileSync(p, 'utf8');
}

function randSecret(len=32) {
  return crypto.randomBytes(len).toString('base64url');
}

async function ensureSuperadmin() {
  const username = process.env.BOOTSTRAP_SUPERADMIN_USERNAME || 'superadmin';
  let password = process.env.BOOTSTRAP_SUPERADMIN_PASSWORD || '';
  if (!password) {
    password = randSecret(18);
    console.log('BOOTSTRAP_SUPERADMIN_PASSWORD was empty. Generated one-time password:', password);
    console.log('Set it permanently by providing BOOTSTRAP_SUPERADMIN_PASSWORD in backend/.env (or container env).');
  }

  const passHash = await bcrypt.hash(password, 12);

  const u = await query('SELECT id FROM users WHERE username=$1', [username]);
  let userId;
  if (u.rowCount === 0) {
    const ins = await query(
      'INSERT INTO users (username, pass_hash, is_superadmin) VALUES ($1,$2,true) RETURNING id',
      [username, passHash]
    );
    userId = ins.rows[0].id;
    console.log(`Created superadmin user: ${username}`);
  } else {
    userId = u.rows[0].id;
    // ensure flag true
    await query('UPDATE users SET is_superadmin=true WHERE id=$1', [userId]);
  }

  // Default server owned by superadmin
  const s = await query('SELECT id FROM servers WHERE name=$1 AND owner_id=$2', ['Home', userId]);
  let serverId;
  if (s.rowCount === 0) {
    const ins = await query('INSERT INTO servers (name, owner_id) VALUES ($1,$2) RETURNING id', ['Home', userId]);
    serverId = ins.rows[0].id;
  } else {
    serverId = s.rows[0].id;
  }

  await query(
    'INSERT INTO memberships (user_id, server_id, role) VALUES ($1,$2,$3) ON CONFLICT DO NOTHING',
    [userId, serverId, 'owner']
  );

  const channels = [
    { name: 'general', type: 'text' },
    { name: 'voice', type: 'voice' },
    { name: 'stream', type: 'voice' }
  ];

  for (const ch of channels) {
    await query(
      `INSERT INTO channels (server_id, name, type)
       SELECT $1, $2, $3
       WHERE NOT EXISTS (
         SELECT 1 FROM channels WHERE server_id=$1 AND name=$2 AND type=$3
       )`,
      [serverId, ch.name, ch.type]
    );
  }
}

export async function initDbIfNeeded() {
  const schema = readSchema();
  await pool.query(schema);
  await ensureSuperadmin();
}

async function main() {
  await initDbIfNeeded();
  console.log('DB initialized.');
  await pool.end();
}

if (import.meta.url === `file://${process.argv[1]}`) {
  main().catch((e) => {
    console.error('db:init failed', e);
    process.exit(1);
  });
}
