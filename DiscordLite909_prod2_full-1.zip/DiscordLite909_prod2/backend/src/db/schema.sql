CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

CREATE TABLE IF NOT EXISTS users (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  username text UNIQUE NOT NULL,
  pass_hash text NOT NULL,
  is_superadmin boolean NOT NULL DEFAULT false,
  disabled boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS servers (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  name text NOT NULL,
  owner_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS channels (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  server_id uuid NOT NULL REFERENCES servers(id) ON DELETE CASCADE,
  name text NOT NULL,
  type text NOT NULL CHECK (type IN ('text','voice')),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS memberships (
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  server_id uuid NOT NULL REFERENCES servers(id) ON DELETE CASCADE,
  role text NOT NULL DEFAULT 'member',
  created_at timestamptz NOT NULL DEFAULT now(),
  PRIMARY KEY (user_id, server_id)
);

CREATE TABLE IF NOT EXISTS messages (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  channel_id uuid NOT NULL REFERENCES channels(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  content text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

-- Invite-only access control
CREATE TABLE IF NOT EXISTS invites (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  kind text NOT NULL CHECK (kind IN ('signup','server')),
  server_id uuid NULL REFERENCES servers(id) ON DELETE CASCADE,
  code_hash text UNIQUE NOT NULL,
  created_by uuid NULL REFERENCES users(id) ON DELETE SET NULL,
  max_uses integer NOT NULL DEFAULT 1 CHECK (max_uses >= 1 AND max_uses <= 100000),
  uses_count integer NOT NULL DEFAULT 0 CHECK (uses_count >= 0),
  expires_at timestamptz NULL,
  revoked boolean NOT NULL DEFAULT false,
  note text NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS invites_kind_idx ON invites(kind);
CREATE INDEX IF NOT EXISTS invites_server_idx ON invites(server_id);
CREATE INDEX IF NOT EXISTS invites_expires_idx ON invites(expires_at);

CREATE TABLE IF NOT EXISTS invite_uses (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  invite_id uuid NOT NULL REFERENCES invites(id) ON DELETE CASCADE,
  user_id uuid NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  used_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS invite_uses_invite_idx ON invite_uses(invite_id);

-- === SuperAdmin Audit Trail (everything every user does) ===
CREATE TABLE IF NOT EXISTS audit_events (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  user_id uuid NULL REFERENCES users(id) ON DELETE SET NULL,
  scope text NOT NULL DEFAULT 'app',
  action text NOT NULL,
  meta jsonb NOT NULL DEFAULT '{}'::jsonb,
  ip text NULL,
  user_agent text NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS audit_events_created_idx ON audit_events(created_at DESC);
CREATE INDEX IF NOT EXISTS audit_events_user_idx ON audit_events(user_id);
CREATE INDEX IF NOT EXISTS audit_events_scope_idx ON audit_events(scope);

-- === Discord bridge: inbound events (bot -> DB) ===
CREATE TABLE IF NOT EXISTS discord_events (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  guild_id text NOT NULL,
  channel_id text NOT NULL,
  message_id text NOT NULL UNIQUE,
  author_id text NULL,
  author_tag text NULL,
  content text NOT NULL,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS discord_events_created_idx ON discord_events(created_at DESC);
CREATE INDEX IF NOT EXISTS discord_events_channel_idx ON discord_events(channel_id);

-- === Discord bridge: outbound webhook outbox (DB -> webhook) ===
CREATE TABLE IF NOT EXISTS discord_outbox (
  id uuid PRIMARY KEY DEFAULT uuid_generate_v4(),
  payload jsonb NOT NULL,
  attempts integer NOT NULL DEFAULT 0,
  last_status integer NULL,
  last_error text NULL,
  last_attempt_at timestamptz NULL,
  next_attempt_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS discord_outbox_next_idx ON discord_outbox(next_attempt_at ASC);
