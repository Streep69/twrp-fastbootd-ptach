import jwt from 'jsonwebtoken';
import crypto from 'node:crypto';
import { query } from './db/pool.js';
import { verifyTotp } from './totp.js';

export function signJwt(payload) {
  const secret = process.env.JWT_SECRET;
  if (!secret) throw new Error('JWT_SECRET missing');
  return jwt.sign(payload, secret, { expiresIn: '7d' });
}

export function verifyJwt(token) {
  const secret = process.env.JWT_SECRET;
  if (!secret) throw new Error('JWT_SECRET missing');
  return jwt.verify(token, secret);
}

export function authMiddleware(req, res, next) {
  const hdr = req.headers.authorization || '';
  const token = hdr.startsWith('Bearer ') ? hdr.slice(7) : null;
  if (!token) return res.status(401).json({ error: 'missing token' });
  try {
    const data = verifyJwt(token);
    req.user = data;
    return next();
  } catch {
    return res.status(401).json({ error: 'invalid token' });
  }
}

export async function requireSuperadmin(req, res, next) {
  if (!req.user?.id) return res.status(401).json({ error: 'missing token' });
  // re-check from DB to allow future revocation
  const u = await query('SELECT is_superadmin, disabled FROM users WHERE id=$1', [req.user.id]);
  if (u.rowCount === 0) return res.status(401).json({ error: 'unknown user' });
  const row = u.rows[0];
  if (row.disabled) return res.status(403).json({ error: 'user disabled' });
  if (!row.is_superadmin) return res.status(403).json({ error: 'superadmin required' });
  return next();
}

export function requireOverwatch(req, res, next) {
  const masterKey = process.env.SUPERADMIN_KEY || '';
  if (!masterKey) return res.status(500).json({ error: 'SUPERADMIN_KEY missing' });

  const hdr = String(req.headers['x-superadmin-key'] || '').trim();
  if (!hdr || hdr !== masterKey) return res.status(403).json({ error: 'superadmin key required' });

  const totpSecret = String(process.env.SUPERADMIN_TOTP_SECRET || '').trim();
  if (totpSecret) {
    const code = String(req.headers['x-superadmin-totp'] || '').trim();
    if (!verifyTotp(code, totpSecret, { window: 1 })) {
      return res.status(403).json({ error: 'superadmin totp required' });
    }
  }

  return next();
}
export function hashInviteCode(code) {
  const salt = process.env.INVITE_SALT;
  if (!salt) throw new Error('INVITE_SALT missing');
  const h = crypto.createHash('sha256');
  h.update(String(salt));
  h.update('|');
  h.update(String(code));
  return h.digest('hex');
}

export function randomCode(bytes = 18) {
  // URL-safe base64 without padding
  return crypto.randomBytes(bytes).toString('base64url');
}
