import crypto from 'node:crypto';

// Minimal Base32 (RFC 4648) decoder (no padding required)
const ALPHABET = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ234567';

function base32DecodeToBuffer(input) {
  const s = String(input || '').toUpperCase().replace(/[^A-Z2-7]/g, '');
  let bits = 0;
  let value = 0;
  const out = [];
  for (const ch of s) {
    const idx = ALPHABET.indexOf(ch);
    if (idx === -1) continue;
    value = (value << 5) | idx;
    bits += 5;
    if (bits >= 8) {
      bits -= 8;
      out.push((value >>> bits) & 0xff);
    }
  }
  return Buffer.from(out);
}

function hotp(keyBuf, counter, digits = 6) {
  const ctr = Buffer.alloc(8);
  // big-endian counter
  let x = BigInt(counter);
  for (let i = 7; i >= 0; i--) {
    ctr[i] = Number(x & 0xffn);
    x >>= 8n;
  }
  const hmac = crypto.createHmac('sha1', keyBuf).update(ctr).digest();
  const offset = hmac[hmac.length - 1] & 0x0f;
  const bin =
    ((hmac[offset] & 0x7f) << 24) |
    ((hmac[offset + 1] & 0xff) << 16) |
    ((hmac[offset + 2] & 0xff) << 8) |
    (hmac[offset + 3] & 0xff);
  const mod = 10 ** digits;
  const code = (bin % mod).toString().padStart(digits, '0');
  return code;
}

export function totpNow(secretBase32, { stepSeconds = 30, digits = 6, t = Date.now() } = {}) {
  const key = base32DecodeToBuffer(secretBase32);
  const counter = Math.floor(t / 1000 / stepSeconds);
  return hotp(key, counter, digits);
}

export function verifyTotp(code, secretBase32, { stepSeconds = 30, digits = 6, window = 1 } = {}) {
  const c = String(code || '').trim();
  if (!/^[0-9]{6,8}$/.test(c)) return false;
  const now = Date.now();
  for (let w = -window; w <= window; w++) {
    const t = now + (w * stepSeconds * 1000);
    const expected = totpNow(secretBase32, { stepSeconds, digits, t });
    if (crypto.timingSafeEqual(Buffer.from(c), Buffer.from(expected))) return true;
  }
  return false;
}
