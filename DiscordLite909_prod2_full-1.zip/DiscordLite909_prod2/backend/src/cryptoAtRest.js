import crypto from 'node:crypto';

const RAW = process.env.MESSAGE_AT_REST_KEY || '';
let KEY = null;

function decodeKey(raw) {
  if (!raw) return null;
  // base64
  try {
    const b = Buffer.from(raw, 'base64');
    if (b.length === 32) return b;
  } catch {}
  // hex
  try {
    const b = Buffer.from(raw, 'hex');
    if (b.length === 32) return b;
  } catch {}
  return null;
}

KEY = decodeKey(RAW);

export function isAtRestEncryptionEnabled() {
  return !!KEY;
}

export function encryptText(plain) {
  if (!KEY) return String(plain ?? '');
  const iv = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv('aes-256-gcm', KEY, iv);
  const ct = Buffer.concat([cipher.update(String(plain), 'utf8'), cipher.final()]);
  const tag = cipher.getAuthTag();
  const payload = {
    v: 1,
    alg: 'AES-256-GCM',
    iv: iv.toString('base64'),
    tag: tag.toString('base64'),
    ct: ct.toString('base64'),
  };
  return 'enc:v1:' + Buffer.from(JSON.stringify(payload), 'utf8').toString('base64');
}

export function decryptText(maybeEnc) {
  const s = String(maybeEnc ?? '');
  if (!KEY) return s;
  if (!s.startsWith('enc:v1:')) return s;
  try {
    const b64 = s.slice('enc:v1:'.length);
    const payload = JSON.parse(Buffer.from(b64, 'base64').toString('utf8'));
    const iv = Buffer.from(payload.iv, 'base64');
    const tag = Buffer.from(payload.tag, 'base64');
    const ct = Buffer.from(payload.ct, 'base64');
    const decipher = crypto.createDecipheriv('aes-256-gcm', KEY, iv);
    decipher.setAuthTag(tag);
    const pt = Buffer.concat([decipher.update(ct), decipher.final()]);
    return pt.toString('utf8');
  } catch {
    return '[decrypt_error]';
  }
}

export function sha256Text(s) {
  return crypto.createHash('sha256').update(String(s ?? ''), 'utf8').digest('hex');
}
