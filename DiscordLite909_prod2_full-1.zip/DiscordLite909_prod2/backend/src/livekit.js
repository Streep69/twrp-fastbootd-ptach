import { AccessToken } from 'livekit-server-sdk';

export function makeLiveKitToken({ userId, username, room, canPublish = true, canSubscribe = true }) {
  const apiKey = process.env.LIVEKIT_API_KEY;
  const apiSecret = process.env.LIVEKIT_API_SECRET;
  if (!apiKey || !apiSecret) throw new Error("LiveKit API key/secret missing");

  const at = new AccessToken(apiKey, apiSecret, {
    identity: userId,
    name: username
  });

  at.addGrant({
    room,
    roomJoin: true,
    canPublish,
    canSubscribe,
    canPublishData: true
  });

  return at.toJwt();
}
