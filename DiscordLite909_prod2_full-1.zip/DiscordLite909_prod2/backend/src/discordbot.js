import dotenv from 'dotenv';
dotenv.config();

import { Client, GatewayIntentBits, Partials } from 'discord.js';
import { query } from './db/pool.js';

const token = process.env.DISCORD_BOT_TOKEN || '';
const guildId = process.env.DISCORD_GUILD_ID || '';
const watchRaw = process.env.DISCORD_WATCH_CHANNEL_IDS || '';
const watch = new Set(watchRaw.split(',').map(s => s.trim()).filter(Boolean));

if (!token) {
  console.error('[discordbot] DISCORD_BOT_TOKEN missing');
  process.exit(1);
}
if (!guildId) {
  console.error('[discordbot] DISCORD_GUILD_ID missing');
  process.exit(1);
}
if (watch.size === 0) {
  console.error('[discordbot] DISCORD_WATCH_CHANNEL_IDS missing/empty');
  process.exit(1);
}

const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent, // requires privileged intent enabled for most bots
  ],
  partials: [Partials.Channel]
});

async function storeEvent(msg) {
  await query(
    `INSERT INTO discord_events (guild_id, channel_id, message_id, author_id, author_tag, content, created_at)
     VALUES ($1,$2,$3,$4,$5,$6,$7)
     ON CONFLICT (message_id) DO NOTHING`,
    [
      msg.guildId,
      msg.channelId,
      msg.id,
      msg.author?.id || null,
      msg.author ? `${msg.author.username}#${msg.author.discriminator}` : null,
      msg.content || '',
      msg.createdAt ? msg.createdAt.toISOString() : new Date().toISOString()
    ]
  );
}

client.on('ready', () => {
  console.log(`[discordbot] logged in as ${client.user?.tag}`);
});

client.on('messageCreate', async (msg) => {
  try {
    if (!msg.guild || msg.guildId !== guildId) return;
    if (msg.author?.bot) return;
    if (!watch.has(msg.channelId)) return;
    await storeEvent(msg);
  } catch (e) {
    console.error('[discordbot] messageCreate error', e);
  }
});

client.login(token).catch((e) => {
  console.error('[discordbot] login failed', e);
  process.exit(1);
});
