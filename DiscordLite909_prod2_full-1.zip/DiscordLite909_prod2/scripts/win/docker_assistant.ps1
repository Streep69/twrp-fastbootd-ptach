Set-StrictMode -Version Latest
$ErrorActionPreference = "Stop"

function Write-Info($m){ Write-Host "[DockerAssist909] $m" -ForegroundColor Cyan }
function Write-Warn($m){ Write-Host "[DockerAssist909] $m" -ForegroundColor Yellow }
function Write-Err($m){ Write-Host "[DockerAssist909] $m" -ForegroundColor Red }

function Cmd-Exists($cmd) {
  $null -ne (Get-Command $cmd -ErrorAction SilentlyContinue)
}

Write-Info "Checking prerequisites…"

# Enable WSL2 feature (needed for Docker Desktop on many systems)
try {
  $wsl = wsl.exe --status 2>$null
} catch {
  Write-Warn "WSL not available; enabling Windows features (may require reboot)."
}

$features = @(
  "Microsoft-Windows-Subsystem-Linux",
  "VirtualMachinePlatform"
)
foreach ($f in $features) {
  $state = (Get-WindowsOptionalFeature -Online -FeatureName $f).State
  if ($state -ne "Enabled") {
    Write-Info "Enabling feature: $f"
    Enable-WindowsOptionalFeature -Online -FeatureName $f -NoRestart | Out-Null
  }
}

if (-not (Cmd-Exists "winget")) {
  Write-Err "winget is missing. Install 'App Installer' from Microsoft Store, then rerun."
  exit 1
}

# Install Docker Desktop
$dockerOk = $false
if (Cmd-Exists "docker") {
  try {
    docker version | Out-Null
    $dockerOk = $true
  } catch { $dockerOk = $false }
}

if (-not $dockerOk) {
  Write-Info "Installing Docker Desktop via winget…"
  winget install --id Docker.DockerDesktop -e --accept-package-agreements --accept-source-agreements
  Write-Warn "Docker Desktop installed. If this is the first install, you may need to log out/in or reboot."
}

# Ensure Docker is running
try {
  docker version | Out-Null
  Write-Info "Docker is ready."
} catch {
  Write-Warn "Docker is installed but not running yet. Start Docker Desktop and rerun if docker commands fail."
}
