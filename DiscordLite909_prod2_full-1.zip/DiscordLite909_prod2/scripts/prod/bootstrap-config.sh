#!/usr/bin/env bash
set -euo pipefail

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$ROOT_DIR"

if [[ ! -f ".env" ]]; then
  cp .env.example .env
fi
if [[ ! -f "backend/.env" ]]; then
  cp backend/.env.example backend/.env
fi
if [[ ! -f "frontend/.env" ]]; then
  cp frontend/.env.example frontend/.env
fi

rand_b64url() {
  # 32 bytes -> base64url
  python3 - <<'PY'
import os,base64
b=os.urandom(32)
print(base64.urlsafe_b64encode(b).decode().rstrip('='))
PY
}

set_kv() {
  local file="$1" key="$2" val="$3"
  if grep -qE "^${key}=" "$file"; then
    # shellcheck disable=SC2016
    sed -i -E "s|^${key}=.*|${key}=${val}|" "$file"
  else
    echo "${key}=${val}" >> "$file"
  fi
}

# Core secrets
JWT_SECRET="$(rand_b64url)"
INVITE_SALT="$(rand_b64url)"
SUPERADMIN_KEY="$(rand_b64url)"
MESSAGE_AT_REST_KEY="$(python3 - <<'PY'
import os,base64
b=os.urandom(32)
print(base64.b64encode(b).decode())
PY
)"

set_kv "backend/.env" "JWT_SECRET" "$JWT_SECRET"
set_kv "backend/.env" "INVITE_SALT" "$INVITE_SALT"
set_kv "backend/.env" "SUPERADMIN_KEY" "$SUPERADMIN_KEY"
set_kv "backend/.env" "MESSAGE_AT_REST_KEY" "$MESSAGE_AT_REST_KEY"

# Defaults
set_kv "backend/.env" "REQUIRE_INVITE" "true"
set_kv "backend/.env" "CORS_ORIGIN" "http://localhost:3000"
set_kv "frontend/.env" "NEXT_PUBLIC_BACKEND_URL" "http://localhost:4000"

echo ""
echo "✅ Config generated:"
echo "  backend/.env: JWT_SECRET, INVITE_SALT, SUPERADMIN_KEY, MESSAGE_AT_REST_KEY"
echo "  frontend/.env: NEXT_PUBLIC_BACKEND_URL"
echo ""
echo "IMPORTANT:"
echo "  Save SUPERADMIN_KEY somewhere safe. You'll need it for the Control Room."
echo ""
