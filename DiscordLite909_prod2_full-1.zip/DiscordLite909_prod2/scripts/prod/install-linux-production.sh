#!/usr/bin/env bash
set -euo pipefail

# One-click production installer for Debian/Ubuntu.
# Requirements: root (sudo), a domain pointing to this server (for HTTPS), and ports open:
# 80/tcp, 443/tcp, 443/udp, 7881/tcp, 3478/udp, 5349/tcp, 50000-60000/udp
#
# Usage:
#   sudo bash scripts/prod/install-linux-production.sh \
#     --domain example.com --email admin@example.com
#
# Optional:
#   --enable-security   (suricata+falco)
#   --enable-discord    (discord bot service)
#   --app-sub app --api-sub api --lk-sub lk

APP_SUB="app"
API_SUB="api"
LK_SUB="lk"
DOMAIN=""
EMAIL=""
ENABLE_SECURITY="false"
ENABLE_DISCORD="false"

while [[ $# -gt 0 ]]; do
  case "$1" in
    --domain) DOMAIN="$2"; shift 2;;
    --email) EMAIL="$2"; shift 2;;
    --app-sub) APP_SUB="$2"; shift 2;;
    --api-sub) API_SUB="$2"; shift 2;;
    --lk-sub) LK_SUB="$2"; shift 2;;
    --enable-security) ENABLE_SECURITY="true"; shift 1;;
    --enable-discord) ENABLE_DISCORD="true"; shift 1;;
    *) echo "Unknown arg: $1"; exit 1;;
  esac
done

if [[ -z "$DOMAIN" || -z "$EMAIL" ]]; then
  echo "Missing required: --domain and --email"
  exit 1
fi

ROOT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")/../.." && pwd)"
cd "$ROOT_DIR"

echo "==> Installing prerequisites (docker, compose plugin, jq, python3)..."
export DEBIAN_FRONTEND=noninteractive
apt-get update -y
apt-get install -y ca-certificates curl gnupg jq python3 python3-venv openssl

if ! command -v docker >/dev/null 2>&1; then
  install -m 0755 -d /etc/apt/keyrings
  curl -fsSL https://download.docker.com/linux/ubuntu/gpg | gpg --dearmor -o /etc/apt/keyrings/docker.gpg
  chmod a+r /etc/apt/keyrings/docker.gpg
  echo \
    "deb [arch=$(dpkg --print-architecture) signed-by=/etc/apt/keyrings/docker.gpg] https://download.docker.com/linux/ubuntu \
    $(. /etc/os-release && echo "$VERSION_CODENAME") stable" > /etc/apt/sources.list.d/docker.list
  apt-get update -y
  apt-get install -y docker-ce docker-ce-cli containerd.io docker-buildx-plugin docker-compose-plugin
fi

echo "==> Generating config + secrets..."
bash scripts/prod/bootstrap-config.sh

APP_DOMAIN="${APP_SUB}.${DOMAIN}"
API_DOMAIN="${API_SUB}.${DOMAIN}"
LK_DOMAIN="${LK_SUB}.${DOMAIN}"

# Update frontend/backend env for production hosts
python3 - <<PY
import re, pathlib
root=pathlib.Path("$ROOT_DIR")
def set_kv(path,key,val):
    p=root/path
    s=p.read_text()
    if re.search(rf"^{re.escape(key)}=", s, flags=re.M):
        s=re.sub(rf"^{re.escape(key)}=.*$", f"{key}={val}", s, flags=re.M)
    else:
        s += f"\n{key}={val}\n"
    p.write_text(s)
set_kv("frontend/.env","NEXT_PUBLIC_BACKEND_URL",f"https://{API_DOMAIN}")
set_kv("backend/.env","CORS_ORIGIN",f"https://{APP_DOMAIN}")
set_kv("backend/.env","LIVEKIT_HOST",f"https://{LK_DOMAIN}")
PY

echo "==> Writing Caddyfile..."
python3 - <<PY
import pathlib
tpl = pathlib.Path("$ROOT_DIR/deploy/Caddyfile.template").read_text()
out = tpl.replace("{{ACME_EMAIL}}","$EMAIL").replace("{{APP_DOMAIN}}","$APP_DOMAIN").replace("{{API_DOMAIN}}","$API_DOMAIN").replace("{{LK_DOMAIN}}","$LK_DOMAIN")
pathlib.Path("$ROOT_DIR/deploy/Caddyfile").write_text(out)
PY

echo "==> Starting services (production reverse proxy + app)..."
docker compose -f docker-compose.yml -f docker-compose.prod.yml up -d --build

if [[ "$ENABLE_SECURITY" == "true" ]]; then
  echo "==> Enabling security profile (suricata + falco)..."
  docker compose -f docker-compose.yml -f docker-compose.security.yml up -d
fi

if [[ "$ENABLE_DISCORD" == "true" ]]; then
  echo "==> Enabling Discord bot service..."
  docker compose -f docker-compose.yml up -d --profile discord --build
fi

echo ""
echo "✅ Production is up:"
echo "  App:  https://${APP_DOMAIN}"
echo "  API:  https://${API_DOMAIN}"
echo "  LiveKit: https://${LK_DOMAIN}"
echo ""
echo "Open the Control Room at: https://${APP_DOMAIN}/admin"
echo "You'll need SUPERADMIN_KEY from backend/.env (x-superadmin-key)."
