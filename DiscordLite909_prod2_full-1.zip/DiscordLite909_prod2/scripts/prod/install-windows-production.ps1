#Requires -RunAsAdministrator
param(
  [Parameter(Mandatory=$true)][string]$Domain,
  [Parameter(Mandatory=$true)][string]$Email,
  [string]$AppSub = "app",
  [string]$ApiSub = "api",
  [string]$LkSub = "lk",
  [switch]$EnableDiscord,
  [switch]$EnableSecurity
)

$ErrorActionPreference = "Stop"
$Root = Resolve-Path (Join-Path $PSScriptRoot "..\..") | Select-Object -ExpandProperty Path
Set-Location $Root

function Ensure-Winget {
  if (-not (Get-Command winget -ErrorAction SilentlyContinue)) {
    throw "winget not found. Install App Installer from Microsoft Store first."
  }
}

function Ensure-DockerDesktop {
  if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
    Ensure-Winget
    Write-Host "Installing Docker Desktop via winget..."
    winget install --id Docker.DockerDesktop -e --accept-package-agreements --accept-source-agreements
    Write-Host "Docker Desktop installed. Start Docker Desktop once, then re-run this script."
    exit 1
  }
}

function Ensure-Python {
  if (-not (Get-Command python -ErrorAction SilentlyContinue)) {
    Ensure-Winget
    Write-Host "Installing Python 3 via winget..."
    winget install --id Python.Python.3.12 -e --accept-package-agreements --accept-source-agreements
  }
}

function New-RandB64Url([int]$Bytes=32) {
  $b = New-Object byte[] $Bytes
  [System.Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($b)
  $s = [Convert]::ToBase64String($b).TrimEnd("=") -replace "\+","-" -replace "/","_"
  return $s
}

function Set-KV([string]$File, [string]$Key, [string]$Value) {
  $p = Join-Path $Root $File
  if (-not (Test-Path $p)) { New-Item -ItemType File -Path $p | Out-Null }
  $lines = Get-Content $p -ErrorAction SilentlyContinue
  $found = $false
  $out = foreach ($l in $lines) {
    if ($l -match "^\Q$Key\E=") { $found = $true; "$Key=$Value" } else { $l }
  }
  if (-not $found) { $out += "$Key=$Value" }
  Set-Content -Path $p -Value $out -Encoding UTF8
}

Ensure-DockerDesktop
Ensure-Python

Write-Host "Generating config + secrets..."
Copy-Item -Force ".env.example" ".env" -ErrorAction SilentlyContinue
Copy-Item -Force "backend\.env.example" "backend\.env" -ErrorAction SilentlyContinue
Copy-Item -Force "frontend\.env.example" "frontend\.env" -ErrorAction SilentlyContinue

$jwt = New-RandB64Url
$invite = New-RandB64Url
$super = New-RandB64Url
$keyBytes = New-Object byte[] 32
[System.Security.Cryptography.RandomNumberGenerator]::Create().GetBytes($keyBytes)
$msgKey = [Convert]::ToBase64String($keyBytes)

Set-KV "backend\.env" "JWT_SECRET" $jwt
Set-KV "backend\.env" "INVITE_SALT" $invite
Set-KV "backend\.env" "SUPERADMIN_KEY" $super
Set-KV "backend\.env" "MESSAGE_AT_REST_KEY" $msgKey
Set-KV "backend\.env" "REQUIRE_INVITE" "true"

$appDomain = "$AppSub.$Domain"
$apiDomain = "$ApiSub.$Domain"
$lkDomain  = "$LkSub.$Domain"

Set-KV "frontend\.env" "NEXT_PUBLIC_BACKEND_URL" "https://$apiDomain"
Set-KV "backend\.env" "CORS_ORIGIN" "https://$appDomain"
Set-KV "backend\.env" "LIVEKIT_HOST" "https://$lkDomain"

Write-Host "Writing Caddyfile..."
$tpl = Get-Content "deploy\Caddyfile.template" -Raw
$cfg = $tpl.Replace("{{ACME_EMAIL}}",$Email).Replace("{{APP_DOMAIN}}",$appDomain).Replace("{{API_DOMAIN}}",$apiDomain).Replace("{{LK_DOMAIN}}",$lkDomain)
Set-Content "deploy\Caddyfile" $cfg -Encoding UTF8

Write-Host "Starting services..."
docker compose -f docker-compose.yml -f docker-compose.prod.yml up -d --build

if ($EnableSecurity) {
  docker compose -f docker-compose.yml -f docker-compose.security.yml up -d
}
if ($EnableDiscord) {
  docker compose -f docker-compose.yml up -d --profile discord --build
}

Write-Host ""
Write-Host "✅ Production is up:"
Write-Host "  App: https://$appDomain"
Write-Host "  API: https://$apiDomain"
Write-Host "  LiveKit: https://$lkDomain"
Write-Host ""
Write-Host "Control Room: https://$appDomain/admin"
Write-Host "SUPERADMIN_KEY saved in backend\.env"
