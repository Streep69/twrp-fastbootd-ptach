---
name: Bug report
about: Report a bug in DiscordLite909
labels: bug
---

## What happened?

## Steps to reproduce

## Expected behavior

## Logs / diagnostics
Attach diagnostics from the SuperAdmin Control Room if possible.

## Environment
- OS:
- Docker version:
- Browser:
