'use client';

import { useEffect, useMemo, useState } from 'react';

const BACKEND = process.env.NEXT_PUBLIC_BACKEND_URL || 'http://localhost:4000';

function api(path, { token, superKey, totp, ...opts } = {}) {
  const headers = {
    'Content-Type': 'application/json',
    ...(opts.headers || {}),
  };
  if (token) headers.Authorization = `Bearer ${token}`;
  if (superKey) headers['x-superadmin-key'] = superKey;
  if (totp) headers['x-superadmin-totp'] = totp;

  return fetch(`${BACKEND}${path}`, {
    ...opts,
    headers,
  });
}

export default function Admin() {
  const [token, setToken] = useState('');
  const [superKey, setSuperKey] = useState('');
  const [totp, setTotp] = useState('');

  const [stats, setStats] = useState(null);
  const [invites, setInvites] = useState([]);
  const [audit, setAudit] = useState([]);
  const [discordEvents, setDiscordEvents] = useState([]);
  const [discordOutbox, setDiscordOutbox] = useState([]);
  const [suricata, setSuricata] = useState([]);
  const [falco, setFalco] = useState([]);

  const [inviteForm, setInviteForm] = useState({
    kind: 'signup',
    serverId: '',
    maxUses: 1,
    expiresInHours: 24,
    note: '',
  });

  const [err, setErr] = useState('');

  useEffect(() => {
    const t = localStorage.getItem('dl909_token');
    const k = localStorage.getItem('dl909_superkey');
    if (t) setToken(t);
    if (k) setSuperKey(k);
  }, []);

  useEffect(() => {
    if (superKey) localStorage.setItem('dl909_superkey', superKey);
    else localStorage.removeItem('dl909_superkey');
  }, [superKey]);

  const auth = useMemo(() => ({ token, superKey, totp }), [token, superKey, totp]);

  async function loadAll() {
    setErr('');
    try {
      const s = await api('/api/admin/stats', auth);
      const sd = await s.json();
      if (!s.ok) throw new Error(sd?.error || 'stats failed');
      setStats(sd);

      const inv = await api('/api/admin/invites', auth);
      const invd = await inv.json();
      if (!inv.ok) throw new Error(invd?.error || 'invites failed');
      setInvites(invd.invites || []);

      const a = await api('/api/admin/audit?limit=80', auth);
      const ad = await a.json();
      if (!a.ok) throw new Error(ad?.error || 'audit failed');
      setAudit(ad.events || []);

      const de = await api('/api/admin/discord/events?limit=80', auth);
      const ded = await de.json();
      if (!de.ok) throw new Error(ded?.error || 'discord events failed');
      setDiscordEvents(ded.events || []);

      const dox = await api('/api/admin/discord/outbox?limit=80', auth);
      const doxd = await dox.json();
      if (!dox.ok) throw new Error(doxd?.error || 'discord outbox failed');
      setDiscordOutbox(doxd.outbox || []);

      const su = await api('/api/admin/security/suricata?limit=50', auth);
      const sud = await su.json();
      if (su.ok) setSuricata(sud.events || []);

      const fa = await api('/api/admin/security/falco?limit=50', auth);
      const fad = await fa.json();
      if (fa.ok) setFalco(fad.events || []);
    } catch (e) {
      setErr(String(e?.message || e));
    }
  }

  async function createInvite() {
    setErr('');
    try {
      const res = await api('/api/admin/invites/create', {
        ...auth,
        method: 'POST',
        body: JSON.stringify({
          kind: inviteForm.kind,
          serverId: inviteForm.kind === 'server' ? inviteForm.serverId : undefined,
          maxUses: Number(inviteForm.maxUses || 1),
          expiresInHours: inviteForm.expiresInHours ? Number(inviteForm.expiresInHours) : null,
          note: inviteForm.note || null,
        }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || 'create invite failed');
      await loadAll();
      alert(`Invite code: ${data.code}`);
    } catch (e) {
      setErr(String(e?.message || e));
    }
  }

  async function revokeInvite(inviteId) {
    setErr('');
    try {
      const res = await api('/api/admin/invites/revoke', {
        ...auth,
        method: 'POST',
        body: JSON.stringify({ inviteId }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || 'revoke failed');
      await loadAll();
    } catch (e) {
      setErr(String(e?.message || e));
    }
  }

  async function testWebhook() {
    setErr('');
    try {
      const res = await api('/api/admin/discord/webhook/test', { ...auth, method: 'POST', body: '{}' });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || 'webhook test failed');
      await loadAll();
      alert('Webhook enqueued. Check outbox for delivery.');
    } catch (e) {
      setErr(String(e?.message || e));
    }
  }

  return (
    <div style={{ padding: 18, maxWidth: 1200, margin: '0 auto' }}>
      <div className="dl909-panel" style={{ padding: 16, marginBottom: 14 }}>
        <div style={{ display: 'flex', gap: 14, alignItems: 'center', justifyContent: 'space-between', flexWrap: 'wrap' }}>
          <div>
            <div className="dl909-h1">Control Room</div>
            <div className="dl909-h2">Superadmin overwatch + audits + invites + security + Discord bridge</div>
          </div>
          <button className="dl909-btn" onClick={loadAll}>Refresh</button>
        </div>

        <div className="dl909-grid" style={{ gridTemplateColumns: '1fr 1fr', marginTop: 12 }}>
          <div>
            <div className="dl909-muted" style={{ fontWeight: 800, marginBottom: 6 }}>JWT token (login required)</div>
            <input className="dl909-input" value={token} onChange={e => setToken(e.target.value)} placeholder="Bearer token" />
          </div>
          <div>
            <div className="dl909-muted" style={{ fontWeight: 800, marginBottom: 6 }}>SUPERADMIN_KEY (x-superadmin-key)</div>
            <input className="dl909-input" value={superKey} onChange={e => setSuperKey(e.target.value)} placeholder="Superadmin key" />
          </div>
          <div>
            <div className="dl909-muted" style={{ fontWeight: 800, marginBottom: 6 }}>Optional TOTP (x-superadmin-totp)</div>
            <input className="dl909-input" value={totp} onChange={e => setTotp(e.target.value)} placeholder="123456" />
          </div>
          <div style={{ display: 'flex', gap: 10, alignItems: 'end' }}>
            <button className="dl909-btn" onClick={testWebhook} style={{ width: '100%' }}>Test Discord Webhook</button>
          </div>
        </div>

        {err ? <div style={{ marginTop: 10, color: '#ffb4b4', fontWeight: 800 }}>{err}</div> : null}
      </div>

      <div className="dl909-grid" style={{ gridTemplateColumns: '1fr 1fr', alignItems: 'start' }}>
        <div className="dl909-panel" style={{ padding: 16 }}>
          <div className="dl909-h1">Stats</div>
          <pre style={{ margin: 0, marginTop: 10, whiteSpace: 'pre-wrap' }}>
            {stats ? JSON.stringify(stats, null, 2) : '—'}
          </pre>
        </div>

        <div className="dl909-panel" style={{ padding: 16 }}>
          <div className="dl909-h1">Invites</div>

          <div style={{ marginTop: 10 }} className="dl909-grid">
            <select className="dl909-select" value={inviteForm.kind} onChange={e => setInviteForm({ ...inviteForm, kind: e.target.value })}>
              <option value="signup">signup</option>
              <option value="server">server</option>
            </select>

            {inviteForm.kind === 'server' ? (
              <input className="dl909-input" value={inviteForm.serverId} onChange={e => setInviteForm({ ...inviteForm, serverId: e.target.value })} placeholder="serverId" />
            ) : null}

            <div className="dl909-grid" style={{ gridTemplateColumns: '1fr 1fr' }}>
              <input className="dl909-input" value={inviteForm.maxUses} onChange={e => setInviteForm({ ...inviteForm, maxUses: e.target.value })} placeholder="maxUses" />
              <input className="dl909-input" value={inviteForm.expiresInHours} onChange={e => setInviteForm({ ...inviteForm, expiresInHours: e.target.value })} placeholder="expiresInHours (blank=never)" />
            </div>

            <input className="dl909-input" value={inviteForm.note} onChange={e => setInviteForm({ ...inviteForm, note: e.target.value })} placeholder="note (optional)" />

            <button className="dl909-btn" onClick={createInvite}>Create invite</button>
          </div>

          <div style={{ marginTop: 12, display: 'grid', gap: 8 }}>
            {(invites || []).slice(0, 30).map(inv => (
              <div key={inv.id} className="dl909-panel" style={{ padding: 10 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10, flexWrap: 'wrap' }}>
                  <div>
                    <div style={{ fontWeight: 900 }}>{inv.kind} • uses {inv.uses_count}/{inv.max_uses}</div>
                    <div className="dl909-muted" style={{ fontSize: 12 }}>
                      id {inv.id} • expires {inv.expires_at || '—'} • revoked {String(inv.revoked)}
                    </div>
                    {inv.note ? <div className="dl909-muted" style={{ fontSize: 12 }}>note: {inv.note}</div> : null}
                  </div>
                  <button className="dl909-btn" onClick={() => revokeInvite(inv.id)} disabled={inv.revoked}>Revoke</button>
                </div>
              </div>
            ))}
            {(invites || []).length === 0 ? <div className="dl909-muted">—</div> : null}
          </div>
        </div>

        <div className="dl909-panel" style={{ padding: 16 }}>
          <div className="dl909-h1">Audit Trail</div>
          <div className="dl909-muted" style={{ marginTop: 6 }}>Everything every user does (HTTP + sockets).</div>
          <div style={{ marginTop: 10, display: 'grid', gap: 8, maxHeight: 520, overflow: 'auto' }}>
            {(audit || []).map(ev => (
              <div key={ev.id} className="dl909-panel" style={{ padding: 10 }}>
                <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10 }}>
                  <div style={{ fontWeight: 900 }}>
                    {ev.action} <span className="dl909-muted" style={{ fontWeight: 700 }}>({ev.scope})</span>
                  </div>
                  <div className="dl909-muted" style={{ fontSize: 12 }}>{new Date(ev.created_at).toLocaleString()}</div>
                </div>
                <div className="dl909-muted" style={{ fontSize: 12, marginTop: 4 }}>
                  user: {ev.username || ev.user_id || '—'} • ip: {ev.ip || '—'}
                </div>
                <pre style={{ margin: 0, marginTop: 6, whiteSpace: 'pre-wrap' }}>{JSON.stringify(ev.meta, null, 2)}</pre>
              </div>
            ))}
            {(audit || []).length === 0 ? <div className="dl909-muted">—</div> : null}
          </div>
        </div>

        <div className="dl909-panel" style={{ padding: 16 }}>
          <div className="dl909-h1">Discord Bridge</div>
          <div className="dl909-muted" style={{ marginTop: 6 }}>
            Inbound messages stored by bot + outbound webhook delivery queue.
          </div>

          <div className="dl909-grid" style={{ gridTemplateColumns: '1fr 1fr', marginTop: 10 }}>
            <div>
              <div style={{ fontWeight: 900 }}>Inbound events</div>
              <div style={{ maxHeight: 260, overflow: 'auto', marginTop: 8, display: 'grid', gap: 8 }}>
                {(discordEvents || []).slice(0, 40).map(d => (
                  <div key={d.id} className="dl909-panel" style={{ padding: 10 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10 }}>
                      <div style={{ fontWeight: 900 }}>{d.author_tag || d.author_id || 'unknown'}</div>
                      <div className="dl909-muted" style={{ fontSize: 12 }}>{new Date(d.created_at).toLocaleString()}</div>
                    </div>
                    <div className="dl909-muted" style={{ fontSize: 12 }}>channel: {d.channel_id} • msg: {d.message_id}</div>
                    <div style={{ marginTop: 6, whiteSpace: 'pre-wrap' }}>{d.content}</div>
                  </div>
                ))}
                {(discordEvents || []).length === 0 ? <div className="dl909-muted">—</div> : null}
              </div>
            </div>

            <div>
              <div style={{ fontWeight: 900 }}>Webhook outbox</div>
              <div style={{ maxHeight: 260, overflow: 'auto', marginTop: 8, display: 'grid', gap: 8 }}>
                {(discordOutbox || []).slice(0, 40).map(o => (
                  <div key={o.id} className="dl909-panel" style={{ padding: 10 }}>
                    <div style={{ display: 'flex', justifyContent: 'space-between', gap: 10 }}>
                      <div style={{ fontWeight: 900 }}>attempts {o.attempts}</div>
                      <div className="dl909-muted" style={{ fontSize: 12 }}>{new Date(o.created_at).toLocaleString()}</div>
                    </div>
                    <div className="dl909-muted" style={{ fontSize: 12 }}>
                      last: {o.last_status || '—'} {o.last_error ? `• ${o.last_error}` : ''}<br/>
                      next: {o.next_attempt_at ? new Date(o.next_attempt_at).toLocaleString() : '—'}
                    </div>
                  </div>
                ))}
                {(discordOutbox || []).length === 0 ? <div className="dl909-muted">—</div> : null}
              </div>
            </div>
          </div>
        </div>

        <div className="dl909-panel" style={{ padding: 16 }}>
          <div className="dl909-h1">Security Sensors</div>
          <div className="dl909-muted" style={{ marginTop: 6 }}>
            Optional: Suricata (network IDS) + Falco (runtime threat detection)
          </div>

          <div className="dl909-grid" style={{ gridTemplateColumns: '1fr 1fr', marginTop: 10 }}>
            <div>
              <div style={{ fontWeight: 900 }}>Suricata</div>
              <div style={{ maxHeight: 260, overflow: 'auto', marginTop: 8, display: 'grid', gap: 8 }}>
                {(suricata || []).slice(0, 40).map((e, i) => (
                  <div key={i} className="dl909-panel" style={{ padding: 10 }}>
                    <div className="dl909-muted" style={{ fontSize: 12 }}>{e?.timestamp || ''} • {e?.event_type || ''}</div>
                    <pre style={{ margin: 0, marginTop: 6, whiteSpace: 'pre-wrap' }}>{JSON.stringify(e, null, 2)}</pre>
                  </div>
                ))}
                {(suricata || []).length === 0 ? <div className="dl909-muted">—</div> : null}
              </div>
            </div>
            <div>
              <div style={{ fontWeight: 900 }}>Falco</div>
              <div style={{ maxHeight: 260, overflow: 'auto', marginTop: 8, display: 'grid', gap: 8 }}>
                {(falco || []).slice(0, 40).map((e, i) => (
                  <div key={i} className="dl909-panel" style={{ padding: 10 }}>
                    <div className="dl909-muted" style={{ fontSize: 12 }}>{e?.time || ''} • {e?.priority || ''}</div>
                    <pre style={{ margin: 0, marginTop: 6, whiteSpace: 'pre-wrap' }}>{JSON.stringify(e, null, 2)}</pre>
                  </div>
                ))}
                {(falco || []).length === 0 ? <div className="dl909-muted">—</div> : null}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
