import './globals.css';

export const metadata = {
  title: 'DiscordLite909',
  description: 'Chat + voice + streaming starter',
};

export default function RootLayout({ children }) {
  return (
    <html lang="en">
      <body className="dl909-body">
        {children}
        <div className="dl909-watermark">STREEP1337</div>
      </body>
    </html>
  );
}
