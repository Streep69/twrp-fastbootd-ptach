'use client';

import { useEffect, useMemo, useState } from 'react';
import io from 'socket.io-client';
import { LiveKitRoom, VideoConference, RoomAudioRenderer, ControlBar } from '@livekit/components-react';
import '@livekit/components-styles';

const BACKEND = process.env.NEXT_PUBLIC_BACKEND_URL || 'http://localhost:4000';
const ICE_SERVERS_JSON = process.env.NEXT_PUBLIC_ICE_SERVERS_JSON || '';

function api(path, opts = {}) {
  return fetch(`${BACKEND}${path}`, {
    ...opts,
    headers: {
      'Content-Type': 'application/json',
      ...(opts.headers || {}),
    },
  });
}

function parseIceServers() {
  if (!ICE_SERVERS_JSON) return undefined;
  try {
    const parsed = JSON.parse(ICE_SERVERS_JSON);
    if (Array.isArray(parsed)) return parsed;
  } catch {}
  return undefined;
}

export default function Home() {
  const [token, setToken] = useState('');
  const [me, setMe] = useState(null);

  const [servers, setServers] = useState([]);
  const [serverId, setServerId] = useState(null);
  const [channels, setChannels] = useState([]);
  const [channelId, setChannelId] = useState(null);

  const [messages, setMessages] = useState([]);
  const [draft, setDraft] = useState('');

  const [lk, setLk] = useState({ url: '', token: '', room: '' });
  const [forceRelay, setForceRelay] = useState(false);

  const [joinInvite, setJoinInvite] = useState('');
  const [joinErr, setJoinErr] = useState('');

  const socket = useMemo(() => {
    if (!token) return null;
    return io(BACKEND, { auth: { token } });
  }, [token]);

  useEffect(() => {
    const saved = localStorage.getItem('dl909_token');
    if (saved) setToken(saved);
  }, []);

  useEffect(() => {
    if (token) localStorage.setItem('dl909_token', token);
    else localStorage.removeItem('dl909_token');
  }, [token]);

  useEffect(() => {
    if (!token) { setMe(null); return; }
    (async () => {
      const res = await api('/api/me', { headers: { Authorization: `Bearer ${token}` } });
      const data = await res.json();
      if (res.ok) setMe(data.user);
      else { setToken(''); setMe(null); }
    })();
  }, [token]);

  useEffect(() => {
    if (!socket) return;
    const onMsg = (msg) => {
      if (msg.channelId === channelId) setMessages((m) => [...m, msg]);
    };
    socket.on('message', onMsg);
    return () => {
      socket.off('message', onMsg);
      socket.disconnect();
    };
  }, [socket, channelId]);

  async function doLogin(username, password) {
    const res = await api('/api/login', { method: 'POST', body: JSON.stringify({ username, password }) });
    const data = await res.json();
    if (!res.ok) throw new Error(data?.error || 'login failed');
    setToken(data.token);
    setMe(data.user);
  }

  async function doRegister(username, password, inviteCode) {
    const res = await api('/api/register', { method: 'POST', body: JSON.stringify({ username, password, inviteCode }) });
    const data = await res.json();
    if (!res.ok) throw new Error(data?.error || 'register failed');
    setToken(data.token);
    setMe(data.user);
  }

  useEffect(() => {
    if (!token) return;
    (async () => {
      const res = await api('/api/servers', { headers: { Authorization: `Bearer ${token}` } });
      const data = await res.json();
      setServers(data.servers || []);
      if (data.servers?.[0]) setServerId(data.servers[0].id);
    })();
  }, [token]);

  useEffect(() => {
    if (!token || !serverId) return;
    (async () => {
      const res = await api(`/api/servers/${serverId}/channels`, { headers: { Authorization: `Bearer ${token}` } });
      const data = await res.json();
      setChannels(data.channels || []);
      const firstText = (data.channels || []).find((c) => c.type === 'text');
      if (firstText) setChannelId(firstText.id);
    })();
  }, [token, serverId]);

  useEffect(() => {
    if (!token || !channelId) return;
    (async () => {
      const res = await api(`/api/channels/${channelId}/messages`, { headers: { Authorization: `Bearer ${token}` } });
      const data = await res.json();
      setMessages(data.messages || []);
      if (socket) socket.emit('joinChannel', { channelId });
    })();
    return () => {
      if (socket) socket.emit('leaveChannel', { channelId });
    };
  }, [token, channelId, socket]);

  async function send() {
    if (!socket || !draft.trim()) return;
    const payload = { channelId, content: draft.trim() };
    setDraft('');
    socket.emit('sendMessage', payload, (ack) => {
      if (!ack?.ok) alert(ack?.error || 'send failed');
    });
  }

  async function joinVoice(ch) {
    const room = `${serverId}:${ch.id}`;
    const res = await api('/api/livekit/token', {
      method: 'POST',
      headers: { Authorization: `Bearer ${token}` },
      body: JSON.stringify({ room }),
    });
    const data = await res.json();
    if (!res.ok) throw new Error(data?.error || 'failed to get livekit token');
    setLk({ url: data.url, token: data.token, room });
  }

  function leaveVoice() {
    setLk({ url: '', token: '', room: '' });
  }

  async function doJoinServerInvite() {
    setJoinErr('');
    try {
      const res = await api('/api/invites/join', {
        method: 'POST',
        headers: { Authorization: `Bearer ${token}` },
        body: JSON.stringify({ inviteCode: joinInvite.trim() }),
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data?.error || 'join failed');
      setJoinInvite('');
      // refresh servers
      const rs = await api('/api/servers', { headers: { Authorization: `Bearer ${token}` } });
      const ds = await rs.json();
      setServers(ds.servers || []);
      if (data.serverId) setServerId(data.serverId);
    } catch (e) {
      setJoinErr(String(e?.message || e));
    }
  }

  function logout() {
    setToken('');
    setMe(null);
    setServers([]);
    setChannels([]);
    setMessages([]);
    setLk({ url: '', token: '', room: '' });
  }

  if (!token) return <Auth onLogin={doLogin} onRegister={doRegister} />;

  const iceServers = parseIceServers();

  return (
    <div className="dl909-wrap">
      <aside className="dl909-panel" style={{ width: 280, padding: 12, overflow: 'auto', margin: 12 }}>
        <div style={{ fontWeight: 800, marginBottom: 10, letterSpacing: 0.4 }}>DiscordLite909</div>

        <div style={sectionTitle}>Servers</div>
        {servers.map((s) => (
          <button key={s.id} onClick={() => setServerId(s.id)} style={btn(serverId === s.id)}>
            {s.name}
          </button>
        ))}

        <div style={sectionTitle}>Join server</div>
        <div style={{ display:'flex', gap: 6 }}>
          <input
            value={joinInvite}
            onChange={(e)=>setJoinInvite(e.target.value)}
            placeholder="Invite code"
            style={inp}
          />
          <button onClick={doJoinServerInvite} style={miniBtn}>Join</button>
        </div>
        {joinErr ? <div style={{ color: '#ff6b6b', fontSize: 12, marginTop: 6 }}>{joinErr}</div> : null}

        <div style={sectionTitle}>Channels</div>
        {channels.map((c) => (
          <button
            key={c.id}
            onClick={() => (c.type === 'text' ? setChannelId(c.id) : joinVoice(c))}
            style={btn(channelId === c.id)}
          >
            {c.type === 'text' ? '# ' : '🔊 '} {c.name}
          </button>
        ))}

        <div style={{ marginTop: 14, fontSize: 12, color: '#aaa', lineHeight: 1.4 }}>
          Logged in as <b style={{ color: '#fff' }}>{me?.username}</b>
          {me?.is_superadmin ? <div style={{ marginTop: 6 }}><a href="/admin" style={{ color:'#9ad' }}>Open SuperAdmin Control Room</a></div> : null}
          <div style={{ marginTop: 8 }}>
            <button onClick={logout} style={{ ...miniBtn, width:'100%' }}>Logout</button>
          </div>
        </div>
      </aside>

      <main style={{ flex: 1, display: 'flex', flexDirection: 'column', margin: 12, gap: 12 }}>
        <header style={{ padding: 12, borderBottom: '1px solid #222', display: 'flex', justifyContent: 'space-between' }}>
          <div>
            <b>Text chat</b>
          </div>
          <div style={{ display:'flex', alignItems:'center', gap: 10 }}>
            <label style={{ fontSize: 12, color:'#bbb', display:'flex', alignItems:'center', gap: 6 }}>
              <input type="checkbox" checked={forceRelay} onChange={(e)=>setForceRelay(e.target.checked)} />
              Force TURN relay (firewall mode)
            </label>
            {lk.token ? (
              <button onClick={leaveVoice} style={miniBtn}>
                Leave voice/stream
              </button>
            ) : (
              <span style={{ color: '#9aa4b2', fontSize: 12 }}>Click a 🔊 channel to join voice + stream</span>
            )}
          </div>
        </header>

        <div style={{ flex: 1, display: 'flex', minHeight: 0 }}>
          <section style={{ flex: 1, display: 'flex', flexDirection: 'column', minWidth: 0 }}>
            <div style={{ flex: 1, overflow: 'auto', padding: 12 }}>
              {messages.map((m) => (
                <div key={m.id} style={{ marginBottom: 10 }}>
                  <b>{m.user?.username}</b>{' '}
                  <span style={{ color: '#778', fontSize: 12 }}>{new Date(m.created_at).toLocaleString()}</span>
                  <div style={{ whiteSpace:'pre-wrap' }}>{m.content}</div>
                </div>
              ))}
            </div>
            <div style={{ borderTop: '1px solid #222', padding: 12, display: 'flex', gap: 8 }}>
              <input
                value={draft}
                onChange={(e) => setDraft(e.target.value)}
                onKeyDown={(e) => (e.key === 'Enter' ? send() : null)}
                placeholder="Message…"
                style={{ ...inp, flex: 1 }}
              />
              <button onClick={send} style={miniBtn}>
                Send
              </button>
            </div>
          </section>

          <section style={{ width: 560, borderLeft: '1px solid #222', minHeight: 0, background: '#0b0d11' }}>
            {lk.token ? (
              <div style={{ height: '100%', display: 'flex', flexDirection: 'column' }}>
                <div style={{ padding: 10, borderBottom: '1px solid #222' }}>
                  <b>Voice / Stream</b>{' '}
                  <span style={{ color: '#9aa4b2', fontSize: 12 }}>Room: {lk.room}</span>
                </div>
                <div style={{ flex: 1, minHeight: 0 }}>
                  <LiveKitRoom
                    serverUrl={lk.url}
                    token={lk.token}
                    connect
                    audio
                    video
                    data-lk-theme="default"
                    connectOptions={{
                      rtcConfig: {
                        iceServers,
                        iceTransportPolicy: forceRelay ? 'relay' : 'all',
                      },
                    }}
                    style={{ height: '100%' }}
                  >
                    <VideoConference />
                    <RoomAudioRenderer />
                    <ControlBar />
                  </LiveKitRoom>
                </div>
              </div>
            ) : (
              <div style={{ padding: 16, color: '#9aa4b2', lineHeight: 1.4 }}>
                <div style={{ fontWeight: 700, color:'#e8e8e8' }}>Streaming</div>
                Join a voice channel to enable voice + video + screen share.
                <div style={{ fontSize: 12, marginTop: 10 }}>
                  Tip: Use the screen-share button in LiveKit to stream your screen (Discord-style “Go Live”).
                </div>
                <div style={{ fontSize: 12, marginTop: 10 }}>
                  If you're on a strict network, toggle <b>Force TURN relay</b> for better connectivity.
                </div>
              </div>
            )}
          </section>
        </div>
      </main>
    </div>
  );
}

const sectionTitle = { fontWeight: 800, margin: '12px 0 8px', color:'#aab3c2', fontSize: 12, textTransform:'uppercase', letterSpacing: 1 };
function btn(active) {
  return {
    width: '100%',
    textAlign: 'left',
    padding: '10px 10px',
    marginBottom: 6,
    borderRadius: 10,
    border: '1px solid #222',
    background: active ? '#141822' : '#0b0d11',
    color: '#e8e8e8',
    cursor: 'pointer',
  };
}

const inp = { width:'100%', padding: 10, borderRadius: 10, border:'1px solid #222', background:'#0b0d11', color:'#e8e8e8' };
const miniBtn = { padding:'10px 12px', borderRadius: 10, border:'1px solid #222', background:'#141822', color:'#e8e8e8', cursor:'pointer' };

function Auth({ onLogin, onRegister }) {
  const [mode, setMode] = useState('login');
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [inviteCode, setInviteCode] = useState('');
  const [err, setErr] = useState('');

  async function submit() {
    setErr('');
    try {
      if (mode === 'login') await onLogin(username, password);
      else await onRegister(username, password, inviteCode);
    } catch (e) {
      setErr(String(e.message || e));
    }
  }

  return (
    <div style={{ maxWidth: 520, margin: '10vh auto', border: '1px solid #222', background:'#0b0d11', color:'#e8e8e8', borderRadius: 16, padding: 20 }}>
      <h2 style={{ marginTop: 0 }}>DiscordLite909</h2>
      <div style={{ display: 'flex', gap: 8, marginBottom: 12 }}>
        <button onClick={() => setMode('login')} style={{ padding: '8px 10px', flex: 1, background: mode==='login' ? '#141822' : '#0b0d11', border:'1px solid #222', color:'#e8e8e8', borderRadius: 10 }}>Login</button>
        <button onClick={() => setMode('register')} style={{ padding: '8px 10px', flex: 1, background: mode==='register' ? '#141822' : '#0b0d11', border:'1px solid #222', color:'#e8e8e8', borderRadius: 10 }}>Register (Invite only)</button>
      </div>
      <input value={username} onChange={(e)=>setUsername(e.target.value)} placeholder="username" style={{ ...inp, marginBottom: 8 }} />
      <input value={password} onChange={(e)=>setPassword(e.target.value)} placeholder="password" type="password" style={{ ...inp, marginBottom: 8 }} />
      {mode === 'register' ? (
        <input value={inviteCode} onChange={(e)=>setInviteCode(e.target.value)} placeholder="invite code" style={{ ...inp, marginBottom: 8 }} />
      ) : null}
      <button onClick={submit} style={{ width:'100%', padding: 10, borderRadius: 10, border:'1px solid #222', background:'#141822', color:'#e8e8e8', cursor:'pointer' }}>Continue</button>
      {err ? <div style={{ color:'#ff6b6b', marginTop: 10, fontSize: 12 }}>{err}</div> : null}
      <div style={{ marginTop: 12, fontSize: 12, color:'#9aa4b2', lineHeight: 1.4 }}>
        Registration requires a SuperAdmin-generated invite. Ask the server owner for one.
      </div>
    </div>
  );
}
