# DiscordLite909 Electron Client

This is a thin desktop wrapper around the web app.

## Configure
Option A (recommended): set env var
- `DL909_APP_URL=https://app.example.com`

Option B: create config file
- Copy `config.example.json` to:
  - Windows: `%APPDATA%\DiscordLite909\config.json` (Electron userData)
  - Linux: `~/.config/DiscordLite909/config.json`
  - macOS: `~/Library/Application Support/DiscordLite909/config.json`

## Run dev
```bash
npm install
npm run start
```

## Build installers
```bash
npm install
npm run dist
```
