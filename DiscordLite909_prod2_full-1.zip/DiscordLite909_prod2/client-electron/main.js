const { app, BrowserWindow, shell, dialog } = require('electron');
const fs = require('fs');
const path = require('path');

const CONFIG_PATH = process.env.DL909_CONFIG_PATH || path.join(app.getPath('userData'), 'config.json');

function readConfig() {
  try {
    const raw = fs.readFileSync(CONFIG_PATH, 'utf8');
    const c = JSON.parse(raw);
    return c && typeof c === 'object' ? c : {};
  } catch {
    return {};
  }
}

function writeConfig(cfg) {
  try {
    fs.mkdirSync(path.dirname(CONFIG_PATH), { recursive: true });
    fs.writeFileSync(CONFIG_PATH, JSON.stringify(cfg, null, 2), 'utf8');
  } catch {}
}

function resolveAppUrl() {
  const envUrl = process.env.DL909_APP_URL;
  if (envUrl) return envUrl;
  const cfg = readConfig();
  if (cfg.appUrl) return cfg.appUrl;
  return 'http://localhost:3000';
}

function createWindow() {
  const cfg = readConfig();
  const state = cfg.windowState || {};
  const win = new BrowserWindow({
    width: state.width || 1280,
    height: state.height || 800,
    x: Number.isFinite(state.x) ? state.x : undefined,
    y: Number.isFinite(state.y) ? state.y : undefined,
    backgroundColor: '#0b0613',
    webPreferences: {
      contextIsolation: true,
      nodeIntegration: false,
      sandbox: true,
      preload: path.join(__dirname, 'preload.js'),
    }
  });

  win.on('close', () => {
    const b = win.getBounds();
    const next = readConfig();
    next.windowState = { x: b.x, y: b.y, width: b.width, height: b.height };
    writeConfig(next);
  });

  const url = resolveAppUrl();
  win.loadURL(url).catch(async (e) => {
    await dialog.showMessageBox(win, {
      type: 'error',
      message: 'Failed to load app URL',
      detail: `${url}\n\n${e?.message || e}`,
    });
  });

  win.webContents.setWindowOpenHandler(({ url }) => {
    shell.openExternal(url);
    return { action: 'deny' };
  });

  return win;
}

// Better Linux screen share support (pipewire)
app.commandLine.appendSwitch('enable-features', 'WebRTCPipeWireCapturer');

app.whenReady().then(() => {
  createWindow();
  app.on('activate', () => {
    if (BrowserWindow.getAllWindows().length === 0) createWindow();
  });
});

app.on('window-all-closed', () => {
  if (process.platform !== 'darwin') app.quit();
});
