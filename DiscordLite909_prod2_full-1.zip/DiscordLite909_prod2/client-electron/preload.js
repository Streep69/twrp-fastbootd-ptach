// Intentionally minimal: no Node APIs exposed.
// Place future safe bridges here if needed.
