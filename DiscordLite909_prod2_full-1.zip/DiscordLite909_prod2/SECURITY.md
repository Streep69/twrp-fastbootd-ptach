# Security Policy

## Reporting
Please do not file public issues for vulnerabilities. Use GitHub private security advisories.

## Notes
This project provides layered defenses (auth, encryption-at-rest, optional IDS/runtime detection),
but no software can guarantee preventing all malware. The goal is risk reduction + fast detection.
