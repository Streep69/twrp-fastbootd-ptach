#!/usr/bin/env node
import fs from 'node:fs';
import path from 'node:path';

const ROOT = process.argv[2] ? path.resolve(process.argv[2]) : process.cwd();
const SKIP_DIR = new Set(['node_modules', '.git', '.next', 'pg_data', 'index', 'security/logs', 'dist', 'build', '.turbo']);
const INCLUDE_EXT = new Set(['.js','.mjs','.cjs','.ts','.tsx','.jsx','.json','.yml','.yaml','.sql','.ps1','.sh','.md']);

const BIDI = new Set([0x202A,0x202B,0x202D,0x202E,0x202C,0x2066,0x2067,0x2068,0x2069]);
const INVISIBLE = new Set([0x200B,0x200C,0x200D,0x2060,0xFEFF,0x00AD]);
const CONTROLS = new Set([...BIDI, ...INVISIBLE]);

function walk(dir, out = []) {
  for (const e of fs.readdirSync(dir, { withFileTypes: true })) {
    const p = path.join(dir, e.name);
    if (e.isDirectory()) {
      if (SKIP_DIR.has(e.name)) continue;
      walk(p, out);
    } else if (e.isFile()) {
      const ext = path.extname(p).toLowerCase();
      if (INCLUDE_EXT.has(ext)) out.push(p);
    }
  }
  return out;
}

function lineStartOffset(text, idx) {
  const i = text.lastIndexOf('\n', idx);
  return i === -1 ? 0 : i + 1;
}
function lineNoFromOffset(text, idx) {
  let n = 1;
  for (let i = 0; i < idx; i++) if (text[i] === '\n') n++;
  return n;
}

function scanFile(file) {
  const buf = fs.readFileSync(file);
  let text;
  try { text = buf.toString('utf8'); } catch { return null; }
  const hits = [];
  for (let i = 0; i < text.length; i++) {
    const code = text.codePointAt(i);
    if (code > 0xFFFF) i++;
    if (CONTROLS.has(code)) hits.push({ index: i, codepoint: 'U+' + code.toString(16).toUpperCase().padStart(4, '0') });
  }
  if (!hits.length) return null;
  return hits.map(h => {
    const line = lineNoFromOffset(text, h.index);
    const col = h.index - lineStartOffset(text, h.index) + 1;
    return { ...h, line, col };
  });
}

const files = walk(ROOT);
const findings = [];
for (const f of files) {
  const r = scanFile(f);
  if (r) findings.push({ file: path.relative(ROOT, f), hits: r });
}
const out = { root: ROOT, scanned: files.length, findings };
if (findings.length) {
  console.error(JSON.stringify(out, null, 2));
  process.exit(2);
}
console.log(JSON.stringify(out, null, 2));
